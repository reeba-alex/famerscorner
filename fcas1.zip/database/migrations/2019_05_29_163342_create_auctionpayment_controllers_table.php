<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAuctionpaymentControllersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('auctionpayment_controllers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->date('paymentdate');
            $table->string('stat');
            $table->bigInteger('bidid')->unsigned();
            $table->foreign('bidid')->references('id')->on('biddings');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('auctionpayment_controllers');
    }
}
