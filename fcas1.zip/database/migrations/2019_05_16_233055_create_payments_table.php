<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->srting('email');
            $table->string('date');
            $table->srting('statuss');
            $table->string('mode');
            $table->bigInteger('cartid')->unsigned();
            $table->foreign('cartid')->references('id')->on('carts');
            $table->bigInteger('cropid')->unsigned();
            $table->foreign('cropid')->references('id')->on('cropregs');
            $table->string('total');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
