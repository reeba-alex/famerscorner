<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCropregsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cropregs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('email');
            $table->string('cropvariety');
            $table->string('expiration');
            $table->string('quantity');
            $table->string('price');
            $table->string('image');
            $table->string('payment');
            $table->string('days');
            $table->string('description');
            $table->bigInteger('cid')->unsigned();
            $table->foreign('cid')->references('id')->on('categories');
            $table->bigInteger('pid')->unsigned();
            $table->foreign('pid')->references('id')->on('products');
            
            
            
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cropregs');
    }
}
