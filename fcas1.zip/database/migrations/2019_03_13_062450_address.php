<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Address extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('address', function (Blueprint $table) {
            $table->bigIncrements('aid');
            $table->timestamps();
			$table->string('housename');
			  $table->integer('houseno');
			  $table->string('country');
			  $table->string('state');
			  $table->string('district');
			  $table->string('panchayath');
			  $table->integer('pin');
			  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('address');
    }
}
