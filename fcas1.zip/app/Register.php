<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
   public $fillable=['photo','aadharcard','taxreceipt','badythacer','kaivashamcer','plan','aaharam'];
}
