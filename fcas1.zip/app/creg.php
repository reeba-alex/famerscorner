<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class creg extends Model
{
    public $fillable=['name','addr','state','city','landmark','pin','ph','addtype'];
}
