<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bidding extends Model
{
    public $fillable=['id','farmerid','bidtime','amount','statuss'];
}
