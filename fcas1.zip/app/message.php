<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class message extends Model
{
public $fillable=['email','message','price'];
}
