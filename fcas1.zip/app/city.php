<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class city extends Model
{
    protected $table="states";
    protected $primarykey="id";

    public $fillable=[
        'name','country_id',
        
    ];
}
