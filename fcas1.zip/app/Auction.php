<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Auction extends Model
{
    public $fillable=['email','name','image','des','start','end','price','status'];
}
