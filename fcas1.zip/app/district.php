<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class district extends Model
{
    protected $table="countries";
    protected $primarykey="id";

    public $fillable=[
        'name',
        
    ];
}
