<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cropreg extends Model
{
    public $fillable=['email','cropvariety','expiration','quantity','value','price','image','days','description'];
}
