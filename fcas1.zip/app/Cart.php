<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    public $fillable=['email','cropid','cropvariety','price','quantity1','expiry','status','email1','sta'];
}
