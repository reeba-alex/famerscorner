<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuctionpaymentController extends Model
{
public $fillable=['paymentdate','stat'];
}
