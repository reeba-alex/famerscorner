<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
     public $fillable=['housename','houseno','country','state','district','panchayath','pin'];
}
