<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payments extends Model
{
    public $fillable=['email','date','statuss','mode','total'];
}
