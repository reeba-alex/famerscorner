<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detail extends Model
{
    public $fillable=['housename','country','state','district','panchayath','pin'];
}
