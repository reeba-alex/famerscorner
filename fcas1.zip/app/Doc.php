<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doc extends Model
{
    //
public $fillable=['email','aadharcard','taxreceipt','plan','aaharam'];
}
	

