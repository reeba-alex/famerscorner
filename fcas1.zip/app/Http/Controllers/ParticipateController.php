<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class ParticipateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }
    public function runningauction(Request $req)
    {
        $date1=date('Y-m-d');
       $far=DB::table('personals')->where('status','=',1)->get();
    $cat=DB::table('categories')->get();
    // $pro=DB::table('products')->get();
    $crop=DB::table('cropregs')->where('email','!=','null')->where('expiration','>=',$date1)->where('quantity','>',0)->get();
        $val=$req->session()->get('email');  
        date_default_timezone_set('Asia/Kolkata'); // CDT
        $date = date('Y-m-d H:i'); 
        $au=DB::table('auction_items')->where('status','go to bid')->get();
        $bid=DB::table('biddings')->where('statuss',1)->get();
        return view('admin.runningauction',compact('au','bid','date1','far','crop','cat'))->with('sess',$val);
      
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $date=date('Y-m-d');
        $au=DB::table('auction_items')->where('status','go to bid')->where('id',$id)->get();
        $bid=DB::table('biddings')->where('id',$id)->select('memberid')->pluck('memberid')->first();
        return view('farmer.auctionview',compact('au','bid'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req)
    {
        $val=$req->session()->get('email');
        date_default_timezone_set('Asia/Kolkata'); // CDT
        
//$current_date = date('d/m/Y == H:i:s');
		$date = date('Y-m-d H:i'); 
      
        $id=$req->input('bb');
        $price=$req->input('price');
        $r=     DB::table('auction_items')->where('id',$id)->update(array(
                         'price'=>$price,'status'=>'go to bid',
             )); 
             $l=     DB::table('biddings')->where('aid',$id)->update(array(
                'amount'=>$price,'memberid'=>$val,'bidtime'=>$date,'statuss'=>1,
    )); 
        // $au=DB::table('auction_items')->where('status','go to bid')->where('end','>=',$date)->where('id',$id)->select('max')->pluck('max')->first();
        // $price=$req->input('price');
    //     if($price==$au)
    //     {
    //         $r=     DB::table('auctions')->where('id',$id)->update(array(
    //             'price'=>$price,'email1'=>$val,'status'=>'get bid',
    // )); 
    // $msg="You Get Auction";
    // $result1=DB::insert("insert into messages(email,message,price,aid,status)values(?,?,?,?,?)",[$val,$msg,$price,$id,'not paid']);
    // return redirect()->back()->with('success','Successfully saved');
    //     }
    //     else{
    //         $r=     DB::table('auctions')->where('id',$id)->update(array(
    //             'price'=>$price,'email1'=>$val,
    // )); }
    return redirect()->back()->with('success','Successfully saved');
        
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
