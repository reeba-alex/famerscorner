<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

class CreditController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    echo $id;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req)
    {
        $email=$req->session()->get('email');
        $id=$req->input('bb');
        $re=DB::table('biddings')->where('id',$id)->select('aid')->pluck('aid')->first();
       

date_default_timezone_set('Asia/Kolkata');
$date=('Y-m-d H:i:s');
$date1=date('Y:m:d');
$date2 = date('Y-m-d H:i:s'); 
$date3=strtotime($date2);
//  echo $date1;
       $data=DB::table('cropregs')
       ->join('reviews','reviews.cropid','=','cropregs.id')
       ->select('reviews.email','reviews.review','reviews.rate','cropregs.cropvariety')
       ->where('cropregs.email',$email)
       ->where('cropregs.expiration','>=',$date1)
       ->get();
       $data1=DB::table('categories')
       ->join('cropregs','categories.id','=','cropregs.cid')
       ->select('categories.name','cropregs.cropvariety','cropregs.expiration','cropregs.quantity','cropregs.value','cropregs.price','cropregs.image','cropregs.days','cropregs.description')
       ->where('cropregs.email',$email)
       ->get();
    //    echo $data;
        //echo $data1;
        $bid=DB::table('biddings')
        ->join('auctionpayment_controllers','auctionpayment_controllers.bidid','=','biddings.id')
        ->select('auctionpayment_controllers.paymentdate','auctionpayment_controllers.stat','biddings.id','biddings.memberid','biddings.amount','biddings.aid')
        ->where('biddings.memberid',$email)
        ->where('auctionpayment_controllers.paymentdate','>=',$date1)
        ->where('auctionpayment_controllers.stat','=','not paid')
        
        ->get();
        $bid1=DB::table('biddings')
        ->join('auctionpayment_controllers','auctionpayment_controllers.bidid','=','biddings.id')
       
        ->where('biddings.memberid',$email)
        ->where('auctionpayment_controllers.paymentdate','>=',$date1)
        ->where('auctionpayment_controllers.stat','=','not paid')
        ->select('biddings.aid')
        ->pluck('biddings.aid')
        ->first();
        $tool=DB::table('auction_items')->where('id',$bid1)->select('toolname')->pluck('toolname')->first();
        $au=DB::table('auction_items')->where('status','go to bid')->where('start','=',$date1)->get();
        $gggg=DB::table('messages')->where('status','paid')->where('email','=',$email)->get();
        
$q=0;
$data=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date1]);


return view('farmer.farmerdocupload',compact('au','data','gggg','bid','tool'))->with('sess',$email);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
