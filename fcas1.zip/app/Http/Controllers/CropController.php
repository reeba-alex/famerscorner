<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class CropController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        $val=$req->session()->get('email');
        $a=DB::table('cropregs','cregs')
              ->join('reviews','reviews.cropid','=','cropregs.id')
              ->join('cregs','reviews.email','=','cregs.email')
            ->select('reviews.id','reviews.review','reviews.rate','cropregs.cropvariety','cregs.name','reviews.email')
          ->where('cropregs.email',$val)
         ->get();
        //  echo $a;
        return view('farmer.viewreview',compact('a'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function auction()
    {
        return view('farmer.regauction');
    }
    public function order(Request $req)
    {
        $val=$req->session()->get('email');
    //     $a=DB::table('payments')
              
    //       ->join('cregs','payments.email','=','cregs.email')
    //         ->select('payments.email','payments.statuss','payments.name','payments.total','cregs.addr','cregs.name')
    //       ->where('payments.email',$val)
    //   ->where('payments.statuss','=','not paid')
    //      ->get();
        // $a=DB::select('select * from payments where email1 = ? ',[$val]);
     $a=DB::table('payments')->where('email1',$val)->where('statuss','not paid')->get();
     $a1=DB::table('payments')->where('email1',$val)->select('email')->pluck('email')->first();
     $c=DB::table('cregs')->where('email',$a1)->select('addr')->pluck('addr')->first();
     $d=DB::table('cregs')->where('email',$a1)->select('name')->pluck('name')->first();
     $pay=DB::table('biddings','auction_items','cregs')
    
         ->join('auctionpayment_controllers','auctionpayment_controllers.aid','=','biddings.id')
         ->join('auction_items','auctionpayment_controllers.aid','=','auction_items.id')
         
   ->select('auction_items.toolname','biddings.amount','biddings.memberid','auctionpayment_controllers.stat','auctionpayment_controllers.id')
 ->where('auction_items.farmerid',$val)
 ->where('auctionpayment_controllers.stat','paid')
 
->get();


     return view('farmer.order',compact('a','c','d','pay'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        $val=$req->session()->get('email');
        $r1=$req->input('croname');
        $file=$req->images->getClientOriginalName();
		$req->images->storeAs('public/upload',$file);
        $r3=$req->input('des');
        $date=date('Y-m-d');

        $result1=DB::insert("insert into auction_items(farmerid,toolname,image,des,start,price,status)values(?,?,?,?,?,?,?)",[$val,$r1,$file,$r3,$date,"0","new"]);
return redirect()->back()->with('success','Insert Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $req,$id)
    {
        $val=$req->session()->get('email');
        $r=$id;
        
        DB::table('cropregs')->where('email',$val)->where('id',$r)->update(array(
            'email'=>'null','expiration'=>0,
)); 
return redirect()->back()->with('success','Deleted Successfully');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
