<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
use DB;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $date=date('Y-m-d');
        $far=DB::table('personals')->where('status','=',1)->get();
     $cat=DB::table('categories')->get();
     // $pro=DB::table('products')->get();
     $crop=DB::table('cropregs')->where('email','!=','null')->where('expiration','>=',$date)->where('quantity','>',0)->get();
          //echo "hallo
          $data=DB::table('categories')->get();
          return view('admin.addcategory',compact('data','far','cat','pro','crop'));
         }
         public function view()
         {
     
            $date=date('Y-m-d');
            $far=DB::table('personals')->where('status','=',1)->get();
         $cat=DB::table('categories')->get();
         // $pro=DB::table('products')->get();
         $crop=DB::table('cropregs')->where('email','!=','null')->where('expiration','>=',$date)->where('quantity','>',0)->get();;
            // $pro=DB::table('products')->get();
           
               //echo "hallo
              
               return view('admin.addcategory1',compact('far','cat','crop'));
              }
     
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $file=	   $request->img1->getClientOriginalName();
		$request->img1->storeAs('public/upload',$file);	
        $users=new Category([
			'name'=>$request->get('cat'),
			'image'=>$file,
			
			
			]);
            $users->save();
            return redirect()->back()->with('alert','successfully category added');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function edit($id)

    {
        $category=Category::find($id);
        $date=date('Y-m-d');
        $far=DB::table('personals')->where('status','=',1)->get();
     $cat=DB::table('categories')->get();
     // $pro=DB::table('products')->get();
     $crop=DB::table('cropregs')->where('email','!=','null')->where('expiration','>=',$date)->where('quantity','>',0)->get();
    return view('admin.editcategory',compact('category','far','cat','pro','crop'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        
        /*$file=	   $request->img1->getClientOriginalName();
		$request->img1->storeAs('public/upload',$file);	*/ 

    $category=Category::find($id);
    $category->name=$request->get('cat');
    
    $category->save();
    return redirect()->back()->with('alert','successfully edited');

    }


    public function update1(Request $request)
    {
        $name=$request->input('id');
        $file=	   $request->img1->getClientOriginalName();
		$request->img1->storeAs('public/upload',$file);	
        $category=Category::find($name);
        
        $category->image=$file;
        $category->save();
        return redirect()->back()->with('alert','successfully edited');

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)

    {
        DB::delete('delete from categories where id = ?',[$id]);
        return redirect()->back()->with('alert','successfully category deleted');
    }
       
    
}
