<?php

namespace App\Http\Controllers;

use App\Auction;
use Illuminate\Http\Request;
use DB;

class AuctionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Auction  $auction
     * @return \Illuminate\Http\Response
     */
    public function show(Auction $auction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Auction  $auction
     * @return \Illuminate\Http\Response
     */
    public function edit(Auction $auction,Request $req,$id)
    {
       
    $val=$req->session()->get('email');
    $a=DB::table('auction_items')->where('id',$id)->get();
    $far=DB::table('personals')->get();
    $cat=DB::table('categories')->get();
    // $pro=DB::table('products')->get();

    $crop=DB::table('cropregs')->get();
     $au=DB::table('auctions')->where('id',$id)->get();
    
                return view('admin.audetails',compact('far','cat','crop','a'))->with('sess',$val);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Auction  $auction
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, Auction $auction)
    {
        date_default_timezone_set('Asia/Kolkata'); // CDT
        
//$current_date = date('d/m/Y == H:i:s');
		$date = date('Y-m-d H:i'); 
        $date1=strtotime($date);
        // echo $date;
        $id=$req->input('bb');
        // echo $id;
        $start=$req->input('g');
        // $end=$req->input('m');
        $price=$req->input('p');
        // $max=$req->input('x');
   $r=     DB::table('auction_items')->where('id',$id)->update(array(
            'start'=>$start,'price'=>$price,'status'=>'go to bid',
  )); 
//  echo $r;
// $e=DB::update('auctions set start = ? where id = ?',[$start,$id]);
// echo $e;
 $result1=DB::insert("insert into biddings(memberid,bidtime,amount,statuss,aid)values(?,?,?,?,?)",['nill',$date,'0',0,$id]);
          return redirect()->back()->with('success','successfully added');
					
						
	 }
	
       
        

   

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Auction  $auction
     * @return \Illuminate\Http\Response
     */
    public function destroy(Auction $auction)
    {
        //
    }
}
