<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\SendEmail;
use Mail;
use DB;
class MailController extends Controller
{
   public function index( Request $request)
    {

        $countries = DB::table("accounts")->where('role',2)->pluck("email","id");
        $date=date('Y-m-d');
       $far=DB::table('personals')->where('status','=',1)->get();
    $cat=DB::table('categories')->get();
    // $pro=DB::table('products')->get();
    $crop=DB::table('cropregs')->where('email','!=','null')->where('expiration','>=',$date)->where('quantity','>',0)->get();
        return view('admin.mail',compact('countries','far','cat','pro','crop'));


        // $name = $request->input("name");
        // $body = $request->input("body");  

        // $data = array('name'=>$name, "body" => $body);
        // Mail::send('admin.mail', $data, function($message) {
        //   $message->to('linsalison@mca.ajce.in', 'Linsa Lison')
        //           ->subject('Login details');
        //   $message->from('questanalisi19@gmail.com','Quest Admin');
        // });
        // return redirect()->back()->with('alert', 'Mail Sent Successfully');




//echo "Email Sent successfully.Check your Inbox";
//         $data = array('name'=>"Linsa", "body" => "Username:'linsalison@mca.ajce.in' Password:Linsa@123");
//         Mail::send('admin.mail', $data, function($message) {
//           $message->to('linsalison@mca.ajce.in', 'Linsa Lison')
//                   ->subject('Login details');
//           $message->from('questanalisi19@gmail.com','Quest Admin');
//         });
//         return redirect()->back()->with('alert', 'Mail Sent Successfully');
// //echo "Email Sent successfully.Check your Inbox";
}

public function sendemail(Request $get)
{
        $this->validate($get,[
                "email"=>"required",
                "subject"=>"required",
                "message"=>"required",
        ]);

        $email=$get->email;
        $subject=$get->subject;
        $message=$get->message;
        Mail::to($email)->send(new SendEmail($subject,$message));
        return redirect()->back()->with('success', 'Mail Sent Successfully');
}
 /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Mail  $register
     * @return \Illuminate\Http\Response
     */
    public function edit(Mail $register,$id)
    {
        $categories=DB::table('categories')->get();
        $categories1=DB::table('cropregs')->where('id',$id)->get();
        $data=DB::table('cropregs')->where('cid',1)->get();
		return view('shopnow3',compact('categories','categories1','data'));
    }



}