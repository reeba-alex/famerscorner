<?php

namespace App\Http\Controllers;

use App\Cropreg;
use Illuminate\Http\Request;
use DB;

class CropregController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function categoryview1()
    {
        $cat=DB::table('categories')->get();
    return view('categoryview1',compact('cat'));
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        $val=$req->session()->get('email');
        $cat=$req->input('cat');
        $id=DB::table('categories')->where('name',$cat)->select('id')->pluck('id')->first();
       
        $cat1=$req->input('croname');
        $pro=$req->input('date');
        $quantity=$req->input('qua');
        $quantity1=$req->input('quan');
        // $oldMarker = $quantity . ' ' . $quantity1;
        $price=$req->input('price');
        $filename4=	   $req->images->getClientOriginalName();
		 $req->images->storeAs('public/upload',$filename4);
       
        // $pay=$req->input('pay');
        $deli=$req->input('delivery');
        $des=$req->input('des');
        $result1=DB::insert("insert into cropregs(email,cropvariety,expiration,quantity,value,price,image,days,description,cid)values(?,?,?,?,?,?,?,?,?,?)",[$val, $cat1,$pro,$quantity,$quantity1,$price,$filename4, $deli,$des,$id]);
        $data1=DB::table('categories')
        ->join('cropregs','categories.id','=','cropregs.cid')
        ->select('cropregs.id','categories.name','cropregs.cropvariety','cropregs.expiration','cropregs.quantity','cropregs.value','cropregs.price','cropregs.image','cropregs.days','cropregs.description')
        ->where('cropregs.email',$val)
        ->where('cropregs.id','>',0)
        ->get();
     //    echo $data;
         //echo $data1;
         return view('farmer.viewproduct',compact('data1'))->with('success','successfully registred');
        // return redirect()->back()->with('alert','successfully Registred');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Cropreg  $cropreg
     * @return \Illuminate\Http\Response
     */
    public function show(Cropreg $cropreg)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Cropreg  $cropreg
     * @return \Illuminate\Http\Response
     */
    public function edit(Cropreg $cropreg,$id ,Request $req)
    {
        $val=$req->session()->get('email');
        if( !empty ( $val ) )
        {
            $data=DB::table('cropregs')->where('id',$id)->get();
            $da=DB::table('cropregs')->where('id',$id)->select('email')->pluck('email')->first();
          $data1=DB::table('personals')->where('email',$da)->get();
          $caqua=DB::table('carts')->where('cropid',$id)->select('quantity1')->pluck('quantity1')->first();
          $d=DB::table('personals')->where('email',$da)->select('did')->pluck('did')->first();
          $data2=DB::table('details')->where('id',$d)->get();
          $date=date('Y-m-d');
    $q=0;
    $crop=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date]);
    $cat=DB::table('categories')->get();
    $states = DB::table("countries")->pluck("name","id");
          return view('singlepage1',compact('data','data1','data2','crop','cat','caqua','states'));
        }
        else
        {
            $data=DB::table('cropregs')->where('id',$id)->get();
        $da=DB::table('cropregs')->where('id',$id)->select('email')->pluck('email')->first();
      $data1=DB::table('personals')->where('email',$da)->get();
      
      $d=DB::table('personals')->where('email',$da)->select('did')->pluck('did')->first();
      $data2=DB::table('details')->where('id',$d)->get();
      $date=date('Y-m-d');
    $q=0;
    $crop=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date]);
    $cat=DB::table('categories')->get();
    $states = DB::table("countries")->pluck("name","id");
        return view('singlepage',compact('data','data1','data2','crop','cat','states'));
        }
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Cropreg  $cropreg
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cropreg $cropreg)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Cropreg  $cropreg
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cropreg $cropreg)
    {
        //
    }
}
