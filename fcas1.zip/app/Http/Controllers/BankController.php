<?php

namespace App\Http\Controllers;

use App\Bank;
use Illuminate\Http\Request;
use DB;

class BankController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function show(Bank $bank)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function edit(Bank $bank,$id,Request $req)
    {
        $val=$req->session()->get('email');
        $total='';
        $status="not buy";
        $date=date('Y-m-d');
        $amount=DB::table('cropregs')
        ->join('carts','carts.cropid','=','cropregs.id')
      ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.expiration','carts.sta')
    ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)->where('carts.id',$id)->where('status',$status)
   ->get();
        
         $c=count($amount);
         for($i=0;$i<$c;$i++)  
       {
       $total=$amount[$i]->quantity1*$amount[$i]->price;
        }
        
          $data=DB::table('cropregs')
                    ->join('carts','carts.cropid','=','cropregs.id')
                   ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.image','carts.sta')
                 ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.id',$id)
               ->get();
                 $cat=DB::table('categories')->get();
          
         $amt=$req->input('amt');
         $cat=DB::table('categories')->get();
		 $cus=DB::table('cregs')->where('email',$val)->get();
         return view('customeraddone',compact('cat','data','total','cus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bank $bank)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bank $bank)
    {
        //
    }
}
