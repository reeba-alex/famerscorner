<?php

namespace App\Http\Controllers;

use App\Payment;
use DB;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        $val=$req->session()->get('email');
        $total='';
        $status="not buy";
        $rr="not paid";
        $date=date('Y-m-d');
        $amount=DB::table('carts')->where('sta','=','0')->where('email',$val)->where('status',$status)->where('expiry','>=','$date')->get();
        $d="Cash On Delivery";
         $c=count($amount);
         for($i=0;$i<$c;$i++)  
       {
       $total=$amount[$i]->quantity1*$amount[$i]->price;
        }
        $vv=DB::table('carts')->where('sta','=','0')->where('email',$val)->where('status',$status)->where('expiry','>=','$date')->get();
        $dd=count($vv);
        for($i=0;$i<$dd;$i++)
        {
            $n=$vv[$i]->id;
            $a=$vv[$i]->price;
            $b=$vv[$i]->cropid;
            $c=$vv[$i]->quantity1;
            $r1=DB::table('cropregs')->where('id',$b)->select('cropvariety')->pluck('cropvariety')->first();
            $r2=DB::table('cropregs')->where('id',$b)->select('email')->pluck('email')->first();
            // DB::delete('delete from carts where sta=?',"stock Out");
         $result1=DB::insert("insert into payments(email,date,statuss,mode,cartid,cropid,total,name,email1)values(?,?,?,?,?,?,?,?,?)",[$val,$date,$rr,$d,$n,$b,$a,$r1,$r2]);
             DB::table('carts')->where('id',$n)->update(array(                                  'status'=>"Buy",
                      )); 
   $r=DB::table('cropregs')->where('id',$b)->select('quantity')->pluck('quantity')->first();
//    echo $c;
//    echo $r;
//    $lk=parseFloat($r)-parseFloat($c);
//     echo $lk;
             
   DB::table('cropregs')->where('id',$b)->update(array(
                'quantity'=>$r-$vv[$i]->quantity1,
               )); 

        }
         $data=DB::table('cropregs')->where('expiration', '>=', date('Y-m-d'))->get();
         $cat=DB::table('categories')->get();
         return view('buy',compact('data','cat'))->with('sess',$val)->with('alert','Payment Successfully Completed.');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function productview(Request $req)
    {
        $val=$req->session()->get('email');
        $date=('Y-m-d');
        $data=DB::table('cropregs')
        ->join('reviews','reviews.cropid','=','cropregs.id')
        ->select('reviews.email','reviews.review','reviews.rate','cropregs.cropvariety')
        ->where('cropregs.email',$val)
        ->where('cropregs.expiration','>=',$date)
        ->get();
        $data1=DB::table('categories')
        ->join('cropregs','categories.id','=','cropregs.cid')
        ->select('cropregs.id','categories.name','cropregs.cropvariety','cropregs.expiration','cropregs.quantity','cropregs.value','cropregs.price','cropregs.image','cropregs.days','cropregs.description')
        ->where('cropregs.email',$val)
        ->where('cropregs.id','>',0)
        ->get();
     //    echo $data;
         //echo $data1;
         return view('farmer.viewproduct',compact('data1'))->with('sess',$val);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function show(Payment $payment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function edit(Payment $payment,$id,Request $req)
    {
        $val=$req->session()->get('email');
        $total='';
        $status="not buy";
        $date=date('Y-m-d');
        // $amount=DB::table('carts')->where('sta','=','0')->where('email',$val)->get();
        $amount=DB::table('cropregs')
              ->join('carts','carts.cropid','=','cropregs.id')
            ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.expiration','carts.sta')
          ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)->where('status',$status)->where('carts.id',$id)
         ->get();
        
         $c=count($amount);
         for($i=0;$i<$c;$i++)  
       {
       $total=$amount[$i]->quantity1*$amount[$i]->price;
        }
      
        $data=DB::table('cropregs')
        ->join('carts','carts.cropid','=','cropregs.id')
       ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.image','cropregs.quantity','carts.sta')
     ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.id',$id)->where('carts.expiry','>=',$date)
     ->get();
      $cat=DB::table('categories')->get();
      $cart=DB::table('carts')->where('id',$id)->get();

$cat=DB::table('categories')->get();
$cus=DB::table('cregs')->where('email',$val)->get();
return view('cartedit',compact('cat','data','total','cus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Payment $payment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Payment $payment)
    {
        //
    }
}
