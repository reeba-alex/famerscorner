<?php

namespace App\Http\Controllers;

use App\Bidding;
use Illuminate\Http\Request;
use DB;
class BiddingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bidding  $bidding
     * @return \Illuminate\Http\Response
     */
    public function show(Bidding $bidding)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bidding  $bidding
     * @return \Illuminate\Http\Response
     */
    public function edit(Bidding $bidding,$id,Request $req)
    {

        $date=date('Y-m-d');
        $val=$req->session()->get('email');
        $date=date('Y-m-d');
        $far=DB::table('personals')->where('status','=',1)->get();
     $cat=DB::table('categories')->get();
     // $pro=DB::table('products')->get();
     $crop=DB::table('cropregs')->where('email','!=','null')->where('expiration','>=',$date)->where('quantity','>',0)->get();
        // $pro=DB::table('products')->get();
        $data1=DB::table('auction_items')
        ->join('biddings','biddings.aid','=','auction_items.id')
        ->select('auction_items.id','auction_items.toolname','auction_items.start','auction_items.image','biddings.memberid','biddings.amount')
        ->where(['auction_items.id'=>$id])
        ->where(['auction_items.start'=>$date])
        ->where(['auction_items.status'=>'stop'])
        ->get();
        
        $data=DB::table('auction_items')
       ->join('biddings','biddings.aid','=','auction_items.id')
       ->select('auction_items.id','auction_items.toolname','auction_items.start','auction_items.image','biddings.memberid','biddings.amount')
       ->where(['auction_items.id'=>$id])
       ->where(['auction_items.start'=>$date])
       ->where(['auction_items.status'=>'go to bid'])
       ->get();
      
       return view('admin.runningauctionview',compact('data','date','far','cat','crop','data1'))->with('sess',$val);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bidding  $bidding
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bidding $bidding)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bidding  $bidding
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bidding $bidding)
    {
        //
    }
}
