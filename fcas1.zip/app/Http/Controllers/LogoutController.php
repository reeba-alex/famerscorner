<?php

namespace App\Http\Controllers;
use DB;

use Illuminate\Http\Request;

class LogoutController extends Controller
{
    public function logout(Request $req)
	
	{
		session_start();
	
		$req->session()->flush();
		session_destroy();
		return view('index');
	}
	public function edit($id,Request $req)
    {
		$val=DB::table("products")->where('id',$id)->pluck("cid");
		$val1=DB::table("categories")->where('id',$val)->get();
	
	   $cat= DB::table("products")->where('id',$id)->get();
	
	   return view('farmer.cropreg3',compact('cat','val1'));
    }
	public function store(request $request) {

		$input=$request->all();
		$images=array();
		if($files=$request->file('images')){
			foreach($files as $file){
				$name=$file->getClientOriginalName();
				$file->move('image',$name);
				$images[]=$name;
			}
			echo "hai";
		}
		


	}
}
