<?php

namespace App\Http\Controllers;

use App\Cart;
use DB;
use App\Cropreg;
use Illuminate\Http\Request;

class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        $val=$req->session()->get('email');
        $total='';
        $status="not buy";
        $date=date('Y-m-d');
        // $amount=DB::table('carts')->where('sta','=','0')->where('email',$val)->get();
        $amount=DB::table('cropregs')
              ->join('carts','carts.cropid','=','cropregs.id')
            ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.expiration','carts.sta')
          ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)->where('status',$status)
         ->get();
        
         $c=count($amount);
         for($i=0;$i<$c;$i++)  
       {
       $total=$amount[$i]->quantity1*$amount[$i]->price;
        }
        
         $data=DB::table('cropregs')
                   ->join('carts','carts.cropid','=','cropregs.id')
                  ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.image','carts.sta')
                ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)
               ->get();
                 $cat=DB::table('categories')->get();
          
        $amt=$req->input('amt');
        $cat=DB::table('categories')->get();
    $cus=DB::table('cregs')->where('email',$val)->get();
    $states = DB::table("countries")->pluck("name","id");
    // echo $val;
        return view('customeradd',compact('cat','data','total','cus','states'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function payment()
    {
        $cat=DB::table('categories')->get();
        $states = DB::table("countries")->pluck("name","id");
        return view('payment',compact('cat','states'));
    }
	 public function reg(Request $req)
    {
        $val=$req->session()->get('email');
		$f=$req->input('name');
		$f1=$req->input('no');
		$f2=$req->input('add');
		$f3=$req->input('pin');
		$f4=$req->input('type');
		DB::table('cregs')->where('email',$val)->update(array(
        'name'=>$f,'addr'=>$f2,'pin'=>$f3,'ph'=>$f1,'addtype'=>$f4,
)); 
		$total='';
        $date=date('Y-m-d');
        $amount=DB::table('carts')->where('sta','=','0')->where('email',$val)->get();
        
         $c=count($amount);
         for($i=0;$i<$c;$i++)  
       {
       $total=$amount[$i]->quantity1*$amount[$i]->price;
        }
        
         $data=DB::table('cropregs')
                   ->join('carts','carts.cropid','=','cropregs.id')
                  ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.image','carts.sta')
                ->where('carts.email',$val)->where('cropregs.expiration','>',$date)
               ->get();
                 $cat=DB::table('categories')->get();
          
        $amt=$req->input('amt');
        $cat=DB::table('categories')->get();
    $cus=DB::table('cregs')->where('email',$val)->get();
    $states = DB::table("countries")->pluck("name","id");
        return view('customeradd',compact('cat','data','total','cus','states'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $req)
    {
        $val=$req->session()->get('email');
        if( !empty ( $val ) )
        {

        $carts = new Cart([
			'email'=>$val,
			
			'cropid'=>$req->get('bb'),
			'cropvariety'=>$req->get('hh'),
			'price'=>$req->get('dd'),
			'quantity'=>$req->get('rr'),
		
			
			]);
            $carts->save();
            return redirect()->back()->with('session','Add To Cart Successfully');
        }
           
            

// return view('quickview');








else{
    return redirect()->back()->with('session','Login please');
}
 }
 public function delete(Request $req,$id)
{
    
}
    public function view(Request $request)
    {
    $val=$request->session()->get('email');
    $date=date('Y-m-d');
  $gg= date('Y-m-d', strtotime($date. ' + 2 days'));
  $status="not buy";
  $a = Cart::where('email',$val)->get();
//   DB::delete('delete from carts where expiry < ?',[$date]);
  $ccc=DB::table('cropregs')
  ->join('carts','carts.cropid','=','cropregs.id')
  ->select('carts.quantity1','carts.cropid','cropregs.id','cropregs.quantity')
  ->where('carts.email',$val)
  ->where('carts.status',$status)
  ->get();
 
//  $ta= DB::table('carts')->where('email',$val)->where('quantity','<','quantity1')->update([
//     'sta'=>'stock Out']); 
    // echo $ta;

//    $rd= DB::table('carts')->where('email',$val)->where('quantity','>',3)->update([
//      'sta'=>'0']); 
    //  echo $rd;
//  $count=count($ccc);
//   echo $count;
//   for($i=0; $i<$count; $i++)
//    {
    
// $quan1=$ccc[$i]->quantity;
//  $quan2=$ccc[$i]->quantity1;
// echo $quan1;
// echo $quan2;

//  if($ccc[$i]->quantity < $ccc[$i]->quantity1)
//    {  
//     DB::table('carts')
//     ->where('email', $val)
//     ->where('cropid',$ccc[$i]->cropid)
//     ->update(['sta' => "stock Out"]);
//         // DB::table('carts')->where('email',$val)->where('cropid',$ccc[$i]->cropid)->update(array(
//         //           'sta'=>'stock Out', )); 

//   }
//  else
//   {
//     DB::table('carts')
//     ->where('email', $val)
//     ->where('cropid',$ccc[$i]->cropid)
//     ->update(['sta' => "0"]);
//     // DB::table('carts')->where('email',$val)->where('cropid',$ccc[$i]->cropid)->update(array(
//     //     'sta'=>0, )); 
//   }
    // }
  $total='';
  $amount=DB::table('cropregs')
              ->join('carts','carts.cropid','=','cropregs.id')
            ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.expiration','carts.sta')
          ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)->where('status',$status)
         ->get();
//   $amount=DB::table('carts')->where('sta','=','0')->where('email',$val)->where('status',$status)->where('expiry','>=','$date')->get();
  
  $c=count($amount);
     for($i=0;$i<$c;$i++)  
     {
  $total=$amount[$i]->quantity1*$amount[$i]->price;
  }
  // echo $total;
    $data=DB::table('cropregs')
              ->join('carts','carts.cropid','=','cropregs.id')
            ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.image','carts.sta')
          ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)->where('status',$status)
         ->get();
            $cat=DB::table('categories')->get();
            $states = DB::table("countries")->pluck("name","id");
      return view('checkout',compact('data','cat','total','states'));
//   $data=DB::table('cropregs')
// 	   ->join('carts','carts.cropid','=','cropregs.id')
//        ->select('cropregs.cropvariety','cropregs.image','cropregs.price','cropregs.quantity','cropregs.id','carts.id')
//        ->where('carts.email',$val)
//       ->get();
//        $data1=DB::table('carts')->where('email',$val)->get();
// 	  return view('cartview',compact('data','data1'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function show(Cart $cart)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function edit(Cart $cart,$id,Request $req)
    {

        $ta= DB::table('carts')->where('id',$id)->update([
                'status'=>'deleted']); 
                return redirect('/cartview');
    }
    
    public function add(Request $req)
    {
       
        $val=$req->session()->get('email');
        $id=$req->input('bb');
        $qu=$req->input('qua');
        $d=DB::table('cropregs')->where('id',$id)->select('cropvariety')->pluck('cropvariety')->first();
        
        $data1=DB::table('cropregs')->where('id',$id)->select('price')->pluck('price')->first();
        $data2=DB::table('cropregs')->where('id',$id)->select('quantity')->pluck('quantity')->first();
        $data3=DB::table('cropregs')->where('id',$id)->select('email')->pluck('email')->first();
        $data4=DB::table('cropregs')->where('id',$id)->select('quantity')->pluck('quantity')->first();
        // echo $data4;
        $data0=DB::table('carts')->where('cropid',$id)->select('quantity1')->pluck('quantity1')->first();
//  echo $data0;
        $date=date('Y-m-d');
  $gg= date('Y-m-d', strtotime($date. ' + 2 days'));
  $status="not buy";
//   $a = Cart::where('email',$val)->where('cropid',$id)->get();
  $a=DB::table('cropregs')
              ->join('carts','carts.cropid','=','cropregs.id')
            ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.expiration','carts.expiry','carts.status')
          ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)->where('status',$status)
         ->get();
//   echo $a;
//   DB::delete('delete from carts where expiry < ?',[$date]);
  if(empty($val)){
    return redirect()->back()->with('success','Login Please');
}
        if(!empty($val))
    
        {
            // if($data0>$data4)
            // {
            //     return redirect()->back()->with('success','cannot add ');
            // }
            if ($a->count() == 0){
		
                $result1=DB::insert("insert into carts(email,cropid,cropvariety,price,quantity1,expiry,status,email1,sta)values(?,?,?,?,?,?,?,?,?)",[$val,$id,$d,$data1,$qu,$gg,$status,$data3,"0"]);
            //   echo $result1;
                return redirect('/cartview');

// // $data=DB::table('cropregs')
// //             ->join('carts','carts.cropid','=','cropregs.id')
// //             ->select('carts.id','carts.cropvariety','carts.price','carts.quantity','cropregs.image')
// //             ->where('carts.email',$val)
// //             ->get();
// //             $cat=DB::table('categories')->get();
// //       return view('checkout',compact('data','cat'));
           }
           else{
            
            foreach ($a as $object)
            {
               
                
           if(($status==$object->status)&&($object->expiry>=$date)&&($object->expiration>$date))
            {
               
                DB::table('carts')->where('email',$val)->where('cropid',$id)->update(array(
                    'quantity1'=>$object->quantity1+$qu,
 )); 
//  $data0=DB::table('carts')->where('cropid',$id)->select('quantity1')->pluck('quantity1')->first();
// //  echo $data0;
//  if ($data0 > $data4)
//  {
 
    // DB::table('carts')->where('email',$val)->where('cropid',$id)->update(array(
    //     'quantity1'=>$data4,
// )); 
// echo "h";
//     return redirect()->back()->with('success','cannot add more quantity because not available');
    // }
//  $data0=DB::table('carts')->where('cropid',$id)->select('quantity1')->pluck('quantity1')->first();
//  if(!($data0 > $data4)) 
//  {
//     echo "hh";
//  return redirect('/cartview');
//  }
return redirect('/cartview');
            }
            if(("Buy"==$object->status)&&($object->expiry>=$date)&&($object->expiration>$date))
            {
               
                $result1=DB::insert("insert into carts(email,cropid,cropvariety,price,quantity1,expiry,status,email1,sta)values(?,?,?,?,?,?,?,?,?)",[$val,$id,$d,$data1,$qu,$gg,$status,$data3,"0"]);
                //   echo $result1;
                    return redirect('/cartview');
}




        }}
 

        }
       
         
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cart $cart)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Cart  $cart
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
        DB::delete('delete from carts where id = ?',[$id]);
        echo "gg";
        // return redirect()->back()->with('alert','successfully category deleted');
    }
}
