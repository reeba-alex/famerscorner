<?php

namespace App\Http\Controllers;

use App\creg;
use Illuminate\Http\Request;
use DB;
class CregController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function categoryview1()
    {
        $cat=DB::table('categories')->get();
        return view('categoryview1',compact('cat'));
    }
    public function categoryview2()
    {
        $cat=DB::table('categories')->get();
        return view('categoryview2',compact('cat'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\creg  $creg
     * @return \Illuminate\Http\Response
     */
    public function show(creg $creg)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\creg  $creg
     * @return \Illuminate\Http\Response
     */
    public function edit(creg $creg,Request $req,$id)
    {
        $val=$req->session()->get('email');
        if( !empty ( $val ) )
        {
            $data=DB::table('cropregs')->where('id',$id)->get();
            $da=DB::table('cropregs')->where('id',$id)->select('email')->pluck('email')->first();
          $data1=DB::table('personals')->where('email',$da)->get();
          
          $d=DB::table('personals')->where('email',$da)->select('did')->pluck('did')->first();
          $data2=DB::table('details')->where('id',$d)->get();
          $date=date('Y-m-d');
          $q=0;
          $crop=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date]);
          $cat=DB::table('categories')->get();
          $caqua=DB::table('carts')->where('cropid',$id)->where('email',$val)->select('quantity1')->pluck('quantity1')->first();
          $states = DB::table("countries")->pluck("name","id");
          return view('singlepage1',compact('data','data1','data2','crop','cat','caqua','states'));
        }
        else
        {
            return redirect()->back()->with('success','Login Please');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\creg  $creg
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, creg $creg)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\creg  $creg
     * @return \Illuminate\Http\Response
     */
    public function destroy(creg $creg)
    {
        //
    }
}
