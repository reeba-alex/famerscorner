<?php

namespace App\Http\Controllers;

use App\Review;
use Illuminate\Http\Request;
use DB;

class ReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        $val=$req->session()->get('email');
        $rate=$req->input('ra');
        $re=$req->input('n');
        $cropid=$req->input('hh');
        $result1=DB::insert("insert into reviews(email,review,rate,cropid)values(?,?,?,?)",[$val,$re,$rate,$cropid]);
        return redirect()->back()->with('sess',$val);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Review  $review
     * @return \Illuminate\Http\Response
     */
    public function show(Review $review)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Review  $review
     * @return \Illuminate\Http\Response
     */
    public function edit(Review $review,Request $req,$id)
    {
        $val=$req->session()->get('email');
        $date=('Y-m-d');
        $data=DB::table('cropregs')
        ->join('reviews','reviews.cropid','=','cropregs.id')
        ->select('reviews.email','reviews.review','reviews.rate','cropregs.cropvariety')
        ->where('cropregs.email',$val)
        ->where('cropregs.expiration','>=',$date)
        ->get();
        $data1=DB::table('categories')
        ->join('cropregs','categories.id','=','cropregs.cid')
        ->select('cropregs.id','categories.name','cropregs.cropvariety','cropregs.expiration','cropregs.quantity','cropregs.value','cropregs.price','cropregs.image','cropregs.days','cropregs.description')
        ->where('cropregs.email',$val)
        ->where('cropregs.id',$id)
        ->get();
     //    echo $data;
         //echo $data1;
         return view('farmer.editcrop',compact('data1'))->with('sess',$val);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Review  $review
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, Review $review)
    {
        $val=$req->session()->get('email');
        $r=$req->input('bb');
        $r1=$req->input('date');
        $r2=$req->input('qua');
        $r3=$req->input('quan');
        $r4=$req->input('price');
        $r5=$req->input('delivery');
        $r6=$req->input('des');
        DB::table('cropregs')->where('email',$val)->where('id',$r)->update(array(
            'expiration'=>$r1,'quantity'=>$r2,'value'=>$r3,'price'=>$r4,'days'=>$r5,'description'=>$r6,
)); 
return redirect('/viewproduct');

    }
    public function update1(Request $req, Review $review)
    {
        $val=$req->session()->get('email');
        $r=$req->input('bb');
        $r1=$req->input('date');
        $r2=$req->input('qua');
        $r3=$req->input('quan');
        $r4=$req->input('price');
        $r5=$req->input('delivery');
        $r6=$req->input('des');
        DB::table('cropregs')->where('email',$val)->where('id',$r)->update(array(
            'expiration'=>$r1,'quantity'=>$r2,'value'=>$r3,'price'=>$r4,'days'=>$r5,'description'=>$r6,
)); 
return redirect('/viewproduct');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Review  $review
     * @return \Illuminate\Http\Response
     */
    public function destroy(Review $review,$id)
    {
        DB::delete('delete from cropregs where id = ?',[$id]);
        return redirect()->back()->with('alert','successfully category deleted');
    }
}
