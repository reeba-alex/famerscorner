<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Product;

class ProductController extends Controller
{
    public function index()
    {
		$categories = DB::table("categories")->get();
        return view('farmer.addproduct',compact('categories'));
        //return view('regg');
    }
    public function regproduct1()
    {
        $countries = DB::table("categories")->pluck("name","id");
        // $val=DB::table("products")->get();
 	$val1=DB::table("categories")->get();
	
	//    $cat= DB::table("products")->get();
	
	   return view('farmer.cropreg3',compact('countries','val1','cat'));
		// $categories = DB::table("categories")->get();
        // return view('farmer.cropreg1',compact('categories'));
        // //return view('regg');
    }
    public function edit(Product $product,$id)
    {
        $cat=DB::table("categories")->where('id',$id)->get();
        return view('farmer.addproduct2',compact('cat'));
    }
    public function store(Request $req)
    {
        $file=	   $req->ln->getClientOriginalName();
		$req->ln->storeAs('public/upload',$file);	
        $val=$req->session()->get('email');
			$name=$req->get('fn');
            $id=$req->get('bb');
            $check=DB::table('products')->where(['name'=>$name])->get();
            if(count($check)==0)
			{
            $result=DB::insert("insert into products(name,image,cid,email) values(?,?,?,?)",[$name,$file,$id,$val]);
			
					 			
			
            return redirect()->back()->with('alert','Crop type added successfully');
            }
            else{
                return redirect()->back()->with('alert','Crop type already exist you can register your crop');
            }
			
    }
    

}
