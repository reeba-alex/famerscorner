<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class Payment2Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $req)
    {
        $id=$req->input('bb');
        $val=$req->session()->get('email');
        $qua=$req->input('qua');
        // echo $id;
        // echo $qua;
        DB::table('carts')->where('id',$id)->update(array(
                      'quantity1'=>$qua,
                      )); 
                    //   echo "done";
        // $date=('Y-m-d');
        //          $total='';
        //  $status="not buy";
    $f=DB::table('carts')->where('id',$id)->select('cropid')->pluck('cropid')->first();
         $data=DB::table('cropregs')->where('id',$f)->get(); 
                
         $da=DB::table('cropregs')->where('id',$f)->select('email')->pluck('email')->first();
       $data1=DB::table('personals')->where('email',$da)->get();
      
       $d=DB::table('personals')->where('email',$da)->select('did')->pluck('did')->first();
   $data2=DB::table('details')->where('id',$d)->get();
     
    //  return view('singlepage',compact('data','data1','data2'));
    $date=date('Y-m-d');
    $q=0;
    $crop=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date]);
    $cat=DB::table('categories')->get();
    $caqua=DB::table('carts')->where('cropid',$f)->where('email',$val)->select('quantity1')->pluck('quantity1')->first();
                return view('singlepage1',compact('data','data1','data2','crop','cat','caqua'))->with('sess',$val);
       
// $amount=DB::table('carts')->where('sta','=','0')->where('email',$val)->get();
//         $amount=DB::table('cropregs')
//               ->join('carts','carts.cropid','=','cropregs.id')
//              ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.expiration','carts.sta')
//            ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)->where('status',$status)->where('carts.id',$id)
//          ->get();
        
//          $c=count($amount);
//          for($i=0;$i<$c;$i++)  
//         {
//         $total=$amount[$i]->quantity1*$amount[$i]->price;
//         }
       
// //         DB::table('carts')->where('id',$id)->update(array(
// //             'quantity1'=>$qua,
// //            )); 
//            $data=DB::table('cropregs')
//         ->join('carts','carts.cropid','=','cropregs.id')
//        ->select('carts.id','carts.cropvariety','carts.price','carts.quantity1','cropregs.image','cropregs.quantity','carts.sta')
//      ->where('carts.email',$val)->where('cropregs.expiration','>',$date)->where('carts.expiry','>=',$date)
//      ->get();
//        $cat=DB::table('categories')->get();
//        $cart=DB::table('carts')->where('id',$id)->get();

// $cat=DB::table('categories')->get();
// $cus=DB::table('cregs')->where('email',$val)->get();
// return view('checkout',compact('cat','data','total','cus'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id,Request $req)
    {
        $val=$req->session()->get('email');
        $total='';
        $status="not buy";
        $rr="not paid";
        $date=date('Y-m-d');
        $amount=DB::table('carts')->where('sta','=','0')->where('email',$val)->where('status',$status)->where('expiry','>=','$date')->where('id',$id)->get();
        $d="Cash On Delivery";
         $c=count($amount);
         for($i=0;$i<$c;$i++)  
       {
       $total=$amount[$i]->quantity1*$amount[$i]->price;
        }
        $vv=DB::table('carts')->where('sta','=','0')->where('email',$val)->where('status',$status)->where('expiry','>=','$date')->where('id',$id)->get();
        $dd=count($vv);
        for($i=0;$i<$dd;$i++)
        {
            $n=$vv[$i]->id;
            $a=$vv[$i]->price;
            $b=$vv[$i]->cropid;
            $c=$vv[$i]->quantity1;
            // DB::delete('delete from carts where sta=?',"stock Out");
            $r1=DB::table('cropregs')->where('id',$b)->select('cropvariety')->pluck('cropvariety')->first();
            $r2=DB::table('cropregs')->where('id',$b)->select('email')->pluck('email')->first();
            // DB::delete('delete from carts where sta=?',"stock Out");
         $result1=DB::insert("insert into payments(email,date,statuss,mode,cartid,cropid,total,name,email1)values(?,?,?,?,?,?,?,?,?)",[$val,$date,$rr,$d,$n,$b,$a,$r1,$r2]);
             DB::table('carts')->where('id',$n)->update(array(                                  'status'=>"Buy",
                      )); 
   $r=DB::table('cropregs')->where('id',$b)->select('quantity')->pluck('quantity')->first();
//    echo $c;
//    echo $r;
//    $lk=parseFloat($r)-parseFloat($c);
//     echo $lk;
             
   DB::table('cropregs')->where('id',$b)->update(array(
                'quantity'=>$r-$vv[$i]->quantity1,
               )); 

        }
         $data=DB::table('cropregs')->where('expiration', '>=', date('Y-m-d'))->get();
         $cat=DB::table('categories')->get();
         return view('buy',compact('data','cat'))->with('sess',$val)->with('alert','Payment Successfully Completed');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
