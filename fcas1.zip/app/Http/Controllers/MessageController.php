<?php

namespace App\Http\Controllers;

use App\message;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\message  $message
     * @return \Illuminate\Http\Response
     */
    public function show(message $message)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\message  $message
     * @return \Illuminate\Http\Response
     */
    public function edit(message $message,$id)
    {
        $far=DB::table('personals')->get();
    $cat=DB::table('categories')->get();
    // $pro=DB::table('products')->get();
   $date=date('Y-m-d');
    $q=0;
    $crop=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date]);
    
    $au1=DB::table('auctions')->where('status','go to bid')->get();
        $au=DB::table('auctions')->where('status','go to bid')->where('id',$id)->where('end','=',$date)->get();
        return view('admin.auctionview',compact('au','far','crop','cat'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\message  $message
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req)
    {
        $id=$req->input('bb');
        $val=$req->input('f');
        $price=$req->input('p');
        $r=     DB::table('auctions')->where('id',$id)->update(array(
            'email1'=>$val,'status'=>'get bid',
)); 
$msg="You Get Auction";
$result1=DB::insert("insert into messages(email,message,price,aid,status)values(?,?,?,?,?)",[$val,$msg,$price,$id,'not paid']);
return redirect()->back()->with('success','Successfully saved');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\message  $message
     * @return \Illuminate\Http\Response
     */
    public function destroy(message $message)
    {
        //
    }
}
