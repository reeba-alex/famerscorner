<?php

namespace App\Http\Controllers;

use App\Register;
use Illuminate\Http\Request;
use DB;
use App\Account;
use App\Detail;
use App\Doc;
use App\Cropreg;


class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$countries = DB::table("districts")->pluck("name","id");
        return view('newfarmer',compact('countries'));
        //return view('regg');
    }
	public function getPanList(Request $request)
    {
        $pans = DB::table("panchas")
        ->where("district_id",$request->district_id)
        ->pluck("name","id");
        return response()->json($pans);
    }
	
	public function reg()
    {
		
        $states = DB::table("countries")->pluck("name","id");
        return view('regg',compact('states'));
        //return view('regg');
    }
	
	
	
	
	
	
	public function newfas(Request $req)
    {
		$val=$req->input('pn');
		
	
        $val=$req->input('pn');
	     $val1=0;
	   $data=DB::table('details')
	  ->join('personals','personals.did','=','details.id')
	  ->select('personals.did','personals.fname','personals.lname','personals.email','personals.ph','details.housename','details.country','details.state','details.district','details.panchayath','details.pin')
	  ->where(['personals.status'=>0,'details.panchayath'=>$val])
	  ->get();
	  $count=count($data);
	  //echo $count;
	 return view('fadetails',compact('data','count'));
    
	
	}
	
	
 public function buyy()
    {

        $cat = DB::table("categories")->get();
        $data=DB::table('cropregs')->where('expiration', '>=', date('Y-m-d'))->get();
        $states = DB::table("countries")->pluck("name","id");
        return view('buy',compact('data','cat','states'));
    }
	 public function galleryy()
    {
        $states = DB::table("countries")->pluck("name","id");
        return view('gallery',compact('states'));
    }
	 public function aboutt()
    {
        $states = DB::table("countries")->pluck("name","id");
        return view('about',compact('states'));
    }
	public function adminho(Request $req)
    {
        $val=$req->session()->get('email');
        $date=date('Y-m-d');
        $far=DB::table('personals')->where('status','=',1)->get();
     $cat=DB::table('categories')->get();
     // $pro=DB::table('products')->get();
     $crop=DB::table('cropregs')->where('email','!=','null')->where('expiration','>=',$date)->where('quantity','>',0)->get();
        $au=DB::table('auction_items')->where('status','new')->get();
        $au1=DB::table('auctions')->where('status','go to bid')->get();
                    return view('admin.admin',compact('far','cat','crop','au','au1'))->with('sess',$val);
    }
	public function farmerho(Request $req)
    {
        $val=$req->session()->get('email');
        $date=date('Y-m-d');
        $date1=date('Y-m-d H:i:s');
    $au=DB::table('auction_items')->where('status','go to bid')->where('start','=',$date)->get();
    $gggg=DB::table('messages')->where('status','not paid')->where('email','=',$val)->get();
    $bid=DB::table('biddings')
    ->join('auctionpayment_controllers','auctionpayment_controllers.bidid','=','biddings.id')
    ->select('auctionpayment_controllers.paymentdate','auctionpayment_controllers.stat','biddings.memberid','biddings.amount','biddings.aid')
    ->where('biddings.memberid',$val)
    ->where('auctionpayment_controllers.paymentdate','>=',$date)
    ->where('auctionpayment_controllers.stat','>=','not paid')
    
    ->get();
    $bid1=DB::table('biddings')
    ->join('auctionpayment_controllers','auctionpayment_controllers.bidid','=','biddings.id')
   
    ->where('biddings.memberid',$val)
    ->where('auctionpayment_controllers.paymentdate','>=',$date)
    ->where('auctionpayment_controllers.stat','>=','not paid')
    ->select('biddings.aid')
    ->pluck('biddings.aid')
    ->first();
    $tool=DB::table('auction_items')->where('id',$bid1)->select('toolname')->pluck('toolname')->first();
$q=0;
$data=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date]);
    return view('farmer.farmerdocupload',compact('gggg','data','au','bid','tool'))->with('sess',$val);
       
    }
    public function shopnow()
    {
        $categories = DB::table("categories")->get();
        $categories1 = DB::table("cropregs")->where('cid',1)->get();
        return view('shopnow',compact('categories','categories1'));
    }
	public function doc(Request $req)
    {
        $val=$req->session()->get('email');
		$data=DB::table('docs')->where(['email'=>$val])->get();
		$cou=count($data);
		return view('farmer.farmerdocupload1',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function sessionopen(Request $req)
    {
        
    }
	public function storefile(Request $request)
    {
	
		$filename1=	   $request->img1->getClientOriginalName();
		$request->img1->storeAs('public/upload',$filename1);
		$filename2=	   $request->img2->getClientOriginalName();
		    $request->img2->storeAs('public/upload',$filename2);
			$filename3=	   $request->img3->getClientOriginalName();
				   $request->img3->storeAs('public/upload',$filename3);
		    
			$filename4=	   $request->img4->getClientOriginalName();
			$request->img4->storeAs('public/upload',$filename4);
			$val=$request->session()->get('email');
			$file=new Doc;
		   $file->email=$val;
		   $file->aadharcard= $filename1;
		   $file->taxreceipt= $filename2;
		   $file->plan= $filename3;
		   $file->aaharam= $filename4;
		   $file-> save();
		   return redirect()->back()->with('alert','uploaded successfully');
		    //echo "yes";
		
	}
       //return view('index');
	     //$val=$request->session()->get('name');
		 //echo $val;
	   
		   
		   
		   /* object for model class
		   if($request->hasFile('img3') and $request->hasFile('img4'))
		   
			   
					$filename1=	   $request->img1->getClientOriginalName();
		            $request->img1->storeAs('public/upload',$filename1);
			
			$filename2=	   $request->img2->getClientOriginalName();
		    $request->img2->storeAs('public/upload',$filename2);
		   		   
				   $filename3=	   $request->img3->getClientOriginalName();
				   $request->img3->storeAs('public/upload',$filename3);
		    
			$filename4=	   $request->img4->getClientOriginalName();
			$request->img4->storeAs('public/upload',$filename4);
		   $file=new Doc;
		   $file->emai=$val;
		   $file->aadharcard= $filename1;
		   $file->taxreceipt= $filename2;
		   $file->plan= $filename3;
		   $file->aaharam= $filename4;
		    echo "yes";
		   //$file-> save();
		     //echo "yes";
					   
			   }*/
		   

	   

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    

    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }
	public function doccc(Register $register)
    {
        $data=DB::table('docs')->get();
        
		return view('ga',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function edit(Register $register,$id,Request $req)
    {
        // $categories=DB::table('categories')->get();
        // $categories1=DB::table('products')->get();
        // $data=DB::table('cropregs')->where('expiration', '>=', date('Y-m-d'))->get();
      
        
        // return view('shopnow2',compact('categories','categories1','data'));
        $val=$req->session()->get('email');
        if(!empty($val))
        {
            $date=date('Y-m-d');
        $q=0;
        $data=Cropreg::where('expiration','>=',$date)->where('quantity','>',0)->where('cid','=',$id)->get();
        $cat=DB::table('categories')->get();
        return view('croppage1',compact('data','cat'));
        }
        else{
        $date=date('Y-m-d');
        $q=0;
        $data=Cropreg::where('expiration','>=',$date)->where('quantity','>',0)->where('cid','=',$id)->get();
        // echo $data;
        // $data=DB::select('select * from cropregs where expiration >= ? and quantity > 0',[$date]);
        $cat=DB::table('categories')->get();
    return view('croppage',compact('data','cat'));
        }


    }
   

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Register $register)
    {
        //
    }
	public function check(Request $request)
    {
        $data=$request->all();
        $usercount=Account::where('username',$data['email'])->count();
        if($usercount>0){
            echo "false";
        }
        else{
            echo "true";die;
        }

        
    }
	
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy(Register $register)
    {
        //
    }
}
