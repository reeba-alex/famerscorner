<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Personal extends Model
{
    public $fillable=['lname','fname','email','ph','image','status'];
}
