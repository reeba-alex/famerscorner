<!DOCTYPE html>
<html lang="en">
<head>

     <title>AgroMart</title>
<!-- 
Hydro Template 
http://www.templatemo.com/tm-509-hydro
-->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css3/bootstrap.min.css">
     <link rel="stylesheet" href="css3/magnific-popup.css">
     <link rel="stylesheet" href="css3/font-awesome.min.css">

     <link rel="stylesheet" href="css3/templatemo-style.css">
	 <!-- Adding oh-autoVal css style -->
<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
<!-- Adding jQuery script. It must be before other script files -->
<script src="js/jquery.min.js"> </script>
<!-- Adding oh-autoVal script file -->
<script src="js/oh-autoval-script.js"></script>
</head>
<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand">AGROMART</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="/home1" class="smoothScroll"><font size="5px">Home</font></a></li>
                         <li><a href="/about" class="smoothScroll"><font size="5px">About</font></a></li>
                         <li><a href="/buy" class="smoothScroll"><font size="5px">Buy</font></a></li>
                         <li><a href="/gallery" class="smoothScroll"><font size="5px">Gallery</font></a></li>
                         
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
                         <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                         <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                         <li class="section-btn"><a href="#" data-toggle="modal" data-target="#modal-form">Sign in </a></li>
						  <li class="section-btn"><a href="/regg">Join</a></li>
                    </ul>
               </div>

          </div>
     </section>


     <!-- HOME -->
     <section id="home" data-stellar-background-ratio="0.5">
          <div class="overlay"></div>
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="home-info">
                              <h1>BUY AND SALE THROUGH ONE WINDOW</h1><center>
                            <span>
							<button id="myBtn"class="btn section-btn smoothScroll" data-toggle="modal" data-target="#modal-form1">Farmer</button>
							<button id="myBtn1" class="btn section-btn smoothScroll" data-toggle="modal" data-target="#modal-form2">Customer</button>
                                  <!-- <a href="#about" class="btn section-btn smoothScroll">Start</a><span></span>
							  <a href="#about" class="btn section-btn smoothScroll">Start</a>--></center>
                              </span>
                         </div>
						 <center>
                              
                    </div>
                    
               </div>
          </div>
     </section>
	 
     <!-- MODAL -->
     <section class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                          <!--   <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Create an account</a></li>-->
                                             <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                           <!--  <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                                  <form action="#" method="post">
                                                       <input type="text" class="form-control" name="name" placeholder="Name" required>
                                                       <input type="telephone" class="form-control" name="telephone" placeholder="Telephone" required>
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                  </form>
												<a href="/regg"><font size="5px">Farmer</font></a>
												  <a href="">Customer</a>
                                             </div>-->

                                             <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="/loginme" method="post">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="email" class="form-control" name="email" placeholder="Email"autocomplete="off" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" autocomplete="off"required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="">Forgot your password?</a>
                                                  </form>
                                             </div>
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>
	 
	 
	 
	 
	 <section class="modal fade" id="modal-form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                           <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Create an account</a></li>
                                           <!--  <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>-->
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                                  <form action="/data" name="register" class="oh-autoval-form" method="post" onsubmit="return">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="text" class="form-control av-name av-required"  av-message="Invalid must be letter not blank"  name="fname" id="firstname" placeholder="First Name" autocomplete="off" >
													   <input type="text" class="form-control av-name av-required" av-message="Invalid must be letter not blank" id="lastname" name="lname" placeholder="Last Name"autocomplete="off" >
                                                       
											           <input type="email" class="form-control av-email av-required" av-message="Invalid email address also required" id="e"  name="email" placeholder="Email"autocomplete="off">
													   
															   
													   
													   <input type="telephone" class="form-control av-phone av-required"  av-message="Invalid phone number also required"name="phone" id="c" placeholder="Telephone" autocomplete="off" >

													   <input type="text" class="form-control av-required av-name av-posnumber"  av-message="Invalid house name also required"name="hname" id="hname" placeholder="House Name" autocomplete="off">
                                                       
													   
													   
													   
													   
													   
													   
													   <select name="country" id="country" autocomplete="off"  class="form-control av-required" av-message="required">
                                                       <option value="">select</option>
                        
							 <option value="India">India</option>
						
                    </select>
													      <select name="state" id="state" autocomplete="off" class="form-control av-required" av-message="required">
                                                       <option value="">select</option>
                        
							 <option value="India">Kerala</option>
						
                    </select>
													   <select name="district" id="district" autocomplete="off" class="form-control av-required" av-message="required">
                                                       <option value="">select</option>
                        @foreach($states as $key => $state)
							 <option value="{{$key}}">{{$state}}</option>
							  @endforeach
                    </select>
													   <input type="text" class="form-control av-required av-name" av-message="must be letter also required" name="pan" id="pan"placeholder="Panchayath Name"autocomplete="off"class="form-control av-required av-name" av-message="Invalid panchayath name">
													   <!--<select name="pan" id="pan" autocomplete="off" required class="form-control">
													   <!--<option value="">select</option>
                        
                    </select>-->
					 
					
                                                       <input type="text" autocomplete="off" class="form-control av-pincode av-required" av-message="6 gigit nuber& required"name="pin" placeholder="Pin Number" >
													   
                                                       
                                                       <input type="password" class="form-control av-password av-required" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars." id="pass1" name="password" placeholder="Password">
                                             
													   

													   
													   
													   <input type="password" class="form-control av-password av-required" name="cpassword" placeholder=" Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.Similar to password">
													      
													   
													   
													   <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                  </form>
												
                                             </div>

                                           <!--  <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="#" method="post">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="https://www.facebook.com/templatemo">Forgot your password?</a>
                                                  </form>
                                             </div>-->
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>
	 
	 
	 
	  <section class="modal fade" id="modal-form2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                          <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Create an account</a></li>
                                            <!-- <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>-->
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                                  <form action="/data1" class="oh-autoval-form" method="post" onsubmit="return">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="text"  name="firstname" id="firstname" placeholder="Name"  class="form-control av-required av-name" av-message="must be letter also required" >
													  
																
                                                       <!--<input type="telephone" class="form-control" name="telephone" placeholder="Telephone" required>-->
                                                       <input type="email" class="form-control av-email av-required" av-message="Invalid email address also required" name="e1" id="e1" placeholder="Email">
													   <input type="password" class="form-control av-pincode av-required" av-message="6 gigit nuber& required" name="password" placeholder="Password" >
													   <input type="password" class="form-control av-email av-required" name="cpassword" placeholder=" Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.Similar to password">
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                  </form>
												<!--<a href="/regg"><font size="5px">Farmer</font></a>
												  <a href="">Customer</a>-->
                                             </div>

                                            <!-- <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="#" method="post">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="https://www.facebook.com/templatemo">Forgot your password?</a>
                                                  </form>
                                             </div>-->
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>
	 


	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	<!-- SCRIPTS -->
	<script type="text/javascript">
    $('#district').change(function(){
    var stateID = $(this).val();    
    if(stateID){
        $.ajax({
           type:"GET",
           url:"{{url('get-city-list')}}?state_id="+stateID,
           success:function(res){               
            if(res){
                $("#pan").empty();
                $("#pan").append('<option>Select</option>');
                $.each(res,function(key,value){
                    $("#pan").append('<option value="'+key+'">'+value+'</option>');
                });
           
            }else{
               $("#pan").empty();
            }
           }
        });
    }else{
        $("#pan").empty();
        
    }      
   });
   </script>
     <script src="js3/jquery.js"></script>
     <script src="js3/bootstrap.min.js"></script>
     <script src="js3/jquery.stellar.min.js"></script>
     <script src="js3/jquery.magnific-popup.min.js"></script>
     <script src="js3/smoothscroll.js"></script>
     <script src="js3/custom.js"></script>
	 

</body>
</html>
