<!DOCTYPE html>
<html lang="zxx">
<head>
<title>AgroMart</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="prezzie Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=Tangerine:400,700" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
  
  <link rel="stylesheet" href="css3/bootstrap.min.css">
     <link rel="stylesheet" href="css3/magnific-popup.css">
     <link rel="stylesheet" href="css3/font-awesome.min.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css3/templatemo-style.css">

  
  </head>
<body>
<!-- banner -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">

	 <div class="about" id="about" style="background-color:pink;">
		<div class="agileits_works-top">
				<!--<div class="col-md-4 about-img-right">
					<img src="images/f1.jpg" alt=" " class="img-responsive" />
				</div>-->
				<div class="col-md-8 agileits_works-grid two">
				 <br>
				 
					 <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="/" class="smoothScroll"><font size="5px">Home</font></a></li>
                         <li><a href="/about" class="smoothScroll"><font size="5px">About</font></a></li>
                         <li><a href="/buy" class="smoothScroll"><font size="5px">Buy</font></a></li>
                         <li><a href="/gallery" class="smoothScroll"><font size="5px">Gallery</font></a></li>
                         
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
                         <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                         <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                         <li class="section-btn"><a href="#" data-toggle="modal" data-target="#modal-form">Sign in </a></li>
												 <li class="section-btn"><a href="#sign_up" data-toggle="modal" data-target="#modal-form1">Join</a></li>
                    </ul>
               </div>
			   </div>
				
		    <div class="clearfix"> </div>
		</div>
		</div>
		</section>
				    <div class="wthree-text">
					
					<div class="heading-setion-w3ls">
						<h3 class="title-w3layouts">In Simple Words <i class="fa fa-bell-o" aria-hidden="true"></i><i class="fa fa-bell" aria-hidden="true"></i></h3>
					
					</div>

					   <p class="para-w3-agile">Our mission is to help elevate the farmer from a mere docile practitioner of a vocation to a self supporting entrepreneur and thus help place agrarian economy of the nation on a healthy footing.</p>
					   <ul class="about-agile">
						<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Organise the Agricultural sector</li>
						<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Improve Agricultural marketing capabilities.


</li><li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Empower Farmers.<li>
						<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Help Farmers overcome debt.</li>
						<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Stop Farmers suicide.</li>
					</ul>
					</div>
					
				
		<div class="agileits_work_grids">
			<ul id="flexiselDemo1">			
				<li>
					<div class="agileits_work_grid view view-sixth">
						<img src="images/fruit.jpg" alt=" " class="img-responsive" />
						
					</div>
				</li>
				<li>
					<div class="agileits_work_grid view view-sixth">
						<img src="images/flower.jpeg" alt=" " class="img-responsive" />
						<!--<div class="mask"><div class="mask">
							<a href="buynow.html" class="info">Buy Now</a>
						</div>
							<a href="buynow.html" class="info">Buy Now</a>
						</div>-->
					</div>

				</li>
				<li>
					<div class="agileits_work_grid view view-sixth">
						<img src="images/vegetables.jpg" alt=" " class="img-responsive" />
						<!--<div class="mask">
							<a href="buynow.html" class="info">Buy Now</a>
						</div>-->
					</div>
				</li>
				<li>
					<div class="agileits_work_grid view view-sixth">
						<img src="images/spice.jpg" alt=" " class="img-responsive" />
						<!--<div class="mask">
							<a href="buynow.html" class="info">Buy Now</a>
						</div>-->
					</div>
				</li>
				<li>
					<div class="agileits_work_grid view view-sixth">
						<img src="images/g5.jpg" alt=" " class="img-responsive" />
						<!--<div class="mask">
							<a href="buynow.html" class="info">Buy Now</a>
						</div>-->
					</div>
				</li>
			</ul>
	
		</div>
	
<!-- //about -->
<!-- team -->
<div class="team" id="team">
	<div class="container">
	<div class="heading-setion-w3ls">
		<h3 class="title-w3layouts">Meet our Team <i class="fa fa-bell-o" aria-hidden="true"></i><i class="fa fa-bell" aria-hidden="true"></i></h3>
	</div>
		<div class="col-md-6 team-left">
			<div class="team1">
				<div class="col-md-4 team-img1">
					<img src="images/author_image.png" alt="" />
				</div>
				<div class="col-md-4 team-info">
					<h4>Carl </h4>
					<p>AgroMart</p>
					<div class="social-icons">
						<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
					</div>
				</div>
			<div class="clearfix"></div>
			</div>
			<div class="team2">
				<div class="col-md-4 team-img2">
					<img src="images/d.jpg" alt="" />
				</div>
				<div class="col-md-4 team-info">
					<h4>Joseph</h4>
					<p>AgroMart</p>
					<div class="social-icons">
						<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
					</div>
				</div>
			<div class="clearfix"></div>
			</div>
		</div>
		<div class="col-md-6 team-right">
			<div class="team3">
				<div class="col-md-4 team-img1">
					<img src="images/e.png" alt="" />
				</div>
				<div class="col-md-4 team-info">
					<h4>Alice</h4>
					<p>AgroMart</p>
					<div class="social-icons">
						<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
					</div>
				</div>
			<div class="clearfix"></div>
			</div>
			<div class="team4">
				<div class="col-md-4 team-img2">
					<img src="images/k.jpg" alt="" />
				</div>
				<div class="col-md-4 team-info">
					<h4>Mathew</h4>
					<p>AgroMart</p>
					<div class="social-icons">
						<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
					</div>
				</div>
			<div class="clearfix"></div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- //team -->
<!-- services -->
	<div class="services" id="services">
		<div class="container">
			<div class="w3l-about-grids">
				<div class="col-md-6 w3ls-about-left">
				<div class="heading-setion-w3ls">
					<h3 class="title-w3layouts white-agileits">Features <i class="fa fa-bell-o" aria-hidden="true"></i><i class="fa fa-bell white-agileits" aria-hidden="true"></i></h3>
				</div>
					<div class="agileits-icon-grid">
						<div class="icon-left hvr-radial-out">
							<i class="fa fa-cog" aria-hidden="true"></i>
						</div>
						<div class="icon-right">
							<h5>Sell or Buy </h5>
							<p class="para-w3-agile">All agriculture produce,</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="agileits-icon-grid">
						<div class="icon-left hvr-radial-out">
							<i class="fa fa-heart" aria-hidden="true"></i>
						</div>
						<div class="icon-right">
							<h5>Auction</h5>
							<p class="para-w3-agile">Admin provide online auction for farmers.</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="agileits-icon-grid">
						<div class="icon-left hvr-radial-out">
							<i class="fa fa-paper-plane" aria-hidden="true"></i>
						</div>
						<div class="icon-right">
							<h5>UserFriendly</h5>
							<p class="para-w3-agile">Our site give userfriendly environment</p>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="col-md-6 w3ls-about-right">
				<div class="heading-setion-w3ls">
					<h3 class="title-w3layouts white-agileits">They Say <i class="fa fa-bell-o" aria-hidden="true"></i><i class="fa fa-bell white-agileits" aria-hidden="true"></i></h3>
				</div>
					<div class="w3ls-about-right-img">
						<div class="test-gri1">
							<div id="owl-demo2" class="owl-carousel">
								<div class="test-grid1">
									<img src="images/team1.jpg" alt="" class="img-r">
									<h4>Ram Kumar</h4>
									<span>FARMER 1</span>
									<p>I am cultivating banana and counut. AgroMart has crossed the boundaries through the website. A lot of farmers and traders contact me by AgroMart and receive herbal advice. </p>
								</div>	
								<div class="agile">
									<div class="test-grid1">
										<img src="images/team2..jpg" alt="" class="img-r">
										<h4>Joseph </h4>
										<span>FARMER 2</span>
										<p>The service of AgroMart website can be called Net Marketing. Effective website for all information of farmers. Congrats on your initiative.</p>
									</div>	
								</div>
								<div class="agile">
									<div class="test-grid1">
										<img src="images/team3.jpg" alt="" class="img-r">
										<h4>John </h4>
										<span>FARMER 3</span>
										<p>Effective website for all information of farmers. Congrats on your initiative. .</p>
									</div>	
								</div>					
							</div>
						</div>	
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //services -->

<!-- gallery -->
<!-- //gallery -->

<!-- testimonials -->
<!-- //testimonials -->
<!--footer-->
	<div class="footer_bottom section">
		<div class="agileits-w3layouts-footer">
			<div class="container">
				<div class="col-md-4 w3-agile-grid">
					<h5>About Us</h5>
					<p>Inspiring All men to farming feild. Make right future for our life and earth.</p>
					   <div class="w3_agileits_social_media team_agile_w3l team footer">
								<ul class="social-icons3">
									
									<li><a href="#" class="wthree_facebook"> <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
									<li><a href="#" class="wthree_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
									<li><a href="#" class="wthree_dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
									<li><a href="#" class="wthree_behance"><i class="fa fa-behance" aria-hidden="true"></i></a></li>
								</ul>
							</div>	
				<div class="image-agileits">
				<img src="images/f1.jpeg" alt="" class="img-r">
				</div>
				<div class="clearfix"> </div>
				</div>
				<div class="col-md-4 w3-agile-grid mid-w3-add">
					<h5>Address</h5>
					<div class="w3-address">
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-phone" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Phone Number</h6>
								<p>+1 9048696205</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-envelope" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Email Address</h6>
								<p>Email :<a href="mailto:example@email.com"> reebaalex097@gmail.com</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="w3-address-grid">
							<div class="w3-address-left">
								<i class="fa fa-map-marker" aria-hidden="true"></i>
							</div>
							<div class="w3-address-right">
								<h6>Location</h6>
								<p>Near Bus Stand Manimala. 
								<span>Telephone : +917034928659</span>
								</p>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<div class="col-md-4 footer-right w3-agile-grid">
					<div class="agile_footer_grid">
					<h5>Latest News</h5>
						<ul class="agileits_w3layouts_footer_grid_list">
							<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
								<a href="#" data-toggle="modal" data-target="#myModal1">New Fertiliser available in market </a>
							</li>
							<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
								<a href="#" data-toggle="modal" data-target="#myModal1">Today  20% discount in new farming tools</a>
							</li>
						<!--	<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
								<a href="#" data-toggle="modal" data-target="#myModal1">Lorem ipsum neque, vulputate </a>
							</li>
							<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
								<a href="#" data-toggle="modal" data-target="#myModal1">Dolor amet sed quam vitae</a>
							</li>
							<li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
								<a href="#" data-toggle="modal" data-target="#myModal1">Lorem ipsum neque, vulputate </a>
							</li>-->
						</ul>
					</div>
				<!--	<h5>Stay in Touch</h5>
					<form action="#" method="post">
						<input type="email" name="Email" placeholder="Email Id" required="">
						<input type="submit" value="Subscribe">
					</form>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="copyright">
	           <p>© 2017 AgroMart. All rights reserved | Design by <a href="#">AgroMart</a></p>
        </div>
  </div>
  <!-- Modal1 -->
			<!--			<div class="modal fade" id="myModal1" tabindex="-1" role="dialog">
							<div class="modal-dialog">
							<!-- Modal content-->
								<!--<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Agromart</h4>
										<img src="images/f2.jpg" alt=" " class="img-responsive">
										<h5>Integer lorem ipsum dolor sit amet </h5>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, rds which don't look even slightly believable..</p>
									</div>
								</div>
							</div>
						</div>-->
						<!-- //Modal1 -->

<!--//footer-->

	<!-- js -->
	
	
	
	 <section class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                           <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Sign In</a></li>
                                           <!--    <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>-->
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
																					 <form action="/loginme" method="post">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="email" style="text-transform:lowercase;" class="form-control" name="email" placeholder="Email" autocomplete="off" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="LOGIN">
                                                     <!--  <a href="">Forgot your password?</a>-->
																										 @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                                                  </form>
                                                <!--  <form action="#" method="post">
                                                       <input type="text" class="form-control" name="name" placeholder="Name" required>
                                                       <input type="telephone" class="form-control" name="telephone" placeholder="Telephone" required>
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                  </form>
												<a href="/regg"><font size="5px">Farmer</font></a>
												  <a href="">Customer</a>-->
                                             </div>

                                          <!--   <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                   <form action="/loginme" method="post">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" autocomplete="off" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="">Forgot your password?</a>
                                                  </form>
                                             </div>-->
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>



		 <section class="modal fade" id="modal-form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                           <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Sign Up</a></li>
                                             <!--  <li ><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>-->
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
								    <a href="/regg"><img src="images/far.jpg" style="width:100px;height:100px;border-radius:100px;"></a> <br>   <a href="#" data-toggle="modal" data-target="#modal-form2"><img src="images/cus.jpg" style="width:100px;height:100px;border-radius:100px;"></a>
                                             </div>
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>

	 
	 
     <section class="modal fade" id="modal-form2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                           <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Sign Up</a></li>
                                             <!--  <li ><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>-->
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                            <form action="/data1" class="oh-autoval-form" method="post" onsubmit="return" id="register">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="text" value="{{old('firstname')}}" name="firstname" id="firstname" placeholder="Name" autocomplete="off" class="form-control" pattern="[a-zA-Z\s]+" required >
                                                       
                                                      		   
													    		   
                                             
																
                                                
                                                       <input type="email" style="text-transform:lowercase;" class="form-control "  name="email" id="e1" placeholder="Email" autocomplete="off" required onChange='Validem1();'>
													   
													   <script>		
function Validem1() 
{
    var val = document.getElementById('e1').value;

    if (!val.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) 
    {
        alert('Incorrect Email');
		
		     document.getElementById('e1').value = "";
        return false;
    }

    return true;
}

</script>
													   
													   <input type="password" class="form-control" required name="password" id="pass" placeholder="Password" onchange='validate01();' autocomplete="off">
													  
													   <script>
                    function validate01() 
{
     var val = document.getElementById('pass').value;

if (!val.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/)) 
{
   alert('Password should contain atleast a capital letter and small letter and a Number with length atleast 6 ');
      
           document.getElementById('pass').focus();
    return false;
}

return true;
}


</script>
													  
													  
													   <input type="password" class="form-control av-password" name="cpassword" id="cpass"placeholder=" Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars. &&&& Similar to password" autocomplete="off" onChange='check();'>
                                                       
													   <script>
													   
	function check(){
			if(document.getElementById("cpass").value!=document.getElementById("pass").value)
			{
			alert('Doesnot match with password');
				
		            document.getElementById('cpass').value = "";
            }
		else{
			alert(' matched');
			}}
	</script>							   
													
													   <input type="submit" class="form-control" name="submit" value="Submit Button">
													   <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   
													   
													   
													   </script>
                                                  </form>
                                              
                                             </div>

                                        
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>

	 <div class="modal fade" id="exampleModalreg" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Choose Your Desired Category</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <div class="register-form">

                  <br>
&nbsp;&nbsp;&nbsp;Already I Have An Account&nbsp;<a href="#" data-toggle="modal" data-target="#exampleModal" >Login?</a>	
<br>  
	  <form action="/data"  method="post" name="register" class="oh-autoval-form"  enctype="multipart/form-data">
									@csrf
                                             
                                             <table><br>  
											 <div>
											 <tr><td><label>FirstName:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"value="{{ old('fname') }}"  name="fname" id="firstname" class="form-control" placeholder="First Name" autocomplete="off"  title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onchange='Validlast1();'>
											 
											 </td></tr></div>
											<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Last Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"value="{{ old('lname') }}" name="lname"class="form-control" id="l" placeholder="Last Name"autocomplete="off"  title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onchange='Validlast();'>
											</td></tr> </div>  <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Email Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="email"id="e" style="text-transform:lowercase;"class="form-control" name="email" placeholder="Email"autocomplete="off" required onchange='Validem();'>
								            </td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td><label> Mobile Number:<label>&nbsp;	&nbsp;&nbsp; </td> <td> <input type="telephone"class="form-control"   value="{{ old('phone') }}"name="phone" id="c" placeholder="Mobile Phone" autocomplete="off" required onchange='Validat();' >

											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											  <div>
											<tr><td> <label>Profile Photo:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file"value="{{ old('fname') }}"  name="pic" id="fileChooser" placeholder="profile pic" class="form-control"accept="image/*" onchange='ValidateFileUpload();' required  >
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>House Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"value="{{ old('hname') }}" name="hname" id="hname" placeholder="House Name" class="form-control"autocomplete="off"  title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onChange='validate();'>
										</td></tr>	 </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Country:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <select name="country"value="{{ old('country') }}" id="country" autocomplete="off" placeholder="country"class="form-control"  av-message="required" required>
                                                       <option value="">Select Country</option>
                        
							 <option value="India">India</option>
						
                    </select>
								          </td></tr>   </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
										<tr><td>	<label> State:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label></td>	&nbsp;   
										<td><select name="state" value="{{ old('state') }}" id="state"  autocomplete="off" placeholder="state" class="form-control" required>
                                                       <option value="">Select State</option>
                        
							 <option value="kerala">Kerala</option>
						
                    </select>
										</td></tr>	 </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
										<tr><td>	 <label>District:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <select id="state" value="{{ old('district') }}" name=district class="form-control" required> 
                       <option value="">Select District</option>                                         
                      @foreach($states as $key => $state)
                      
							 <option value="{{$state}}">{{$state}}</option>
							  @endforeach
                                     </select>
										</td></tr>	 </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>
											 Panchayath Name:</label>&nbsp;</td>
											<td> <input type="text"  av-message="must be letter also required" value="{{ old('pan') }}" name="pan" class="form-control"id="pan"placeholder="Panchayath Name"autocomplete="off" title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onchange='validate1();'>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Pincode: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"  autocomplete="off"  av-message="6 gigit nuber& required"name="pin"  id="pin" class="form-control"placeholder="Pin Number" title="Only six digit Number" required pattern="[1-9][0-9]{5}+$" onchange='validate0();' >
											
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Password:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars." class="form-control"id="pass" name="password" placeholder="Password" onchange='validate01();' required>
													
					
                                                                   
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Confirm Password:</label>&nbsp;</td>
											<td> <input type="password"  name="cpassword" id="cpass" class="form-control" placeholder="Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.Similar to password" onChange='check();' required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label><font color="yellow">Document Upload**</font></label>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Aadhar Card:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file" placeholder="Aadhar Card" name="img1"class="form-control" accept="application/pdf, application/vnd.ms-excel" required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Tax Receipt:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file" placeholder="Tax" name="img2" class="form-control"accept="application/pdf, application/vnd.ms-excel" required>
                                           </td></tr>  </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											  <div>
											<tr><td> <label>Plan:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file"  placeholder="plan" name="img3"class="form-control" accept="application/pdf, application/vnd.ms-excel" required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Aadharam:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file"  placeholder="Aadharam" name="img4"class="form-control" accept="application/pdf, application/vnd.ms-excel" required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 
        
       

											
											
                                            
													     <script>		
function Validlast1() 
{
    var val = document.getElementById('firstname').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet ');
		            document.getElementById('firstname').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('firstname').focus();
        return false;
    }


    return true;
}

</script>     

                              <script>		
function Validlast() 
{
    var val = document.getElementById('l').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet');
        document.getElementById('l').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('l').focus();
        return false;
    }

    return true;
}

</script>             



          
          <script>		
function Validem() 
{
    var val = document.getElementById('e').value;

    if (!val.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/)) 
    {
        alert('Incorrect Email.Use email format');
		
		    document.getElementById('e').focus();
        return false;
    }

    return true;
}

</script>													   
													   
                                                                 

<script>		
function Validat() 
{
    var val = document.getElementById('c').value;

    if (!val.match(/^[6-9][0-9]{9,9}$/))
    {
        alert('Only Numbers are allowed start with 6,7,8,9 and contain 10 digits');
	
		
        document.getElementById('c').focus();
        return false;
    }

    return true;
}

</script>
													   
												
                                                                 
                                                                    <SCRIPT type="text/javascript">
    function ValidateFileUpload() {
        var fuData = document.getElementById('fileChooser');
        var FileUploadPath = fuData.value;

//To check if user upload any file
        if (FileUploadPath == '') {
            alert("Please upload an image");

        } else {
            var Extension = FileUploadPath.substring(
                    FileUploadPath.lastIndexOf('.') + 1).toLowerCase();

//The file uploaded is an image

if (Extension == "gif" || Extension == "png" || Extension == "bmp"
                    || Extension == "jpeg" || Extension == "jpg") {

// To Display
                if (fuData.files && fuData.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#blah').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(fuData.files[0]);
                }

            } 

//The file upload is NOT an image
else {
                alert("Photo only allows file types of GIF, PNG, JPG, JPEG and BMP. ");
                document.getElementById('fileChooser').focus();
            }
        }
    }
</SCRIPT>
													
										
												

												
												<script>		
function validate() 
{
    var val = document.getElementById('hname').value;

    if (!val.match(/^[0-9a-zA-Z ]+$/)) 
    {
        alert('Only alphabets and numbers are allowed');
        document.getElementById('hname').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('hname').focus();
        return false;
    }

    return true;
}

</script>
												
												
												
												
												
																	
													   
													   
													   
													   
													   
											
                                                                    <script>		
function validate1() 
{
    var val = document.getElementById('pan').value;

    if (!val.match(/^[a-zA-Z ]+$/)) 
    {
        alert('Only alphabets are allowed');
        document.getElementById('pan').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('pan').focus();
        return false;
    }

    return true;
}

</script>
                                                                    
                                                                   
                    <script>
                    function validate0() 
{
    var val = document.getElementById('pin').value;

    if (!val.match(/^\d{6}$/)) 
    {
        alert('Only 6 digit number allowed');
        document.getElementById('pin').focus();
        return false;
    }

    return true;
}

</script>
            


                    

                                                                    <script>
                    function validate01() 
{
     var val = document.getElementById('pass').value;

if (!val.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/)) 
{
   alert('Password should contain atleast a capital letter and small letter and a Number with length atleast 6 ');
      
           document.getElementById('pass').focus();
    return false;
}

return true;
}


</script>
          
                                    
                                                 
                                                 
                                                 
                                                 
                                               
                                                            <script>	      
											function check(){
			if(document.getElementById("cpass").value!=document.getElementById("pass").value)
			{
			alert('Doesnot match with password');
				
               document.getElementById('cpass').focus();
            }
                                                       }
	
   </script>	
    <tr>     <td> <input type="submit"style="width:200px;background-color:lightgreen;" class="form-control" name="submit" value="Submit">
													  </td><tr>
                                                                  
                                                       
                                                       
                                                
                                                                    
                                                                     <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   </script>
													   
													   
                                                </table>		   
                                                  </form>



                     
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>









<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- for-Clients -->
		<script src="js/owl.carousel.js"></script>
			<!-- requried-jsfiles-for owl -->
							        <script>
									    $(document).ready(function() {
									      $("#owl-demo2").owlCarousel({
									        items : 1,
									        lazyLoad : false,
									        autoPlay : true,
									        navigation : false,
									        navigationText :  false,
									        pagination : true,
									      });
									    });
									  </script>
			<!-- //requried-jsfiles-for owl -->
	<!-- //for-Clients -->
 <script type="text/javascript">
					$(window).load(function() {
						$("#flexiselDemo1").flexisel({
							visibleItems: 4,
							animationSpeed: 1000,
							autoPlay: false,
							autoPlaySpeed: 3000,    		
							pauseOnHover: true,
							enableResponsiveBreakpoints: true,
							responsiveBreakpoints: { 
								portrait: { 
									changePoint:568,
									visibleItems: 1
								}, 
								landscape: { 
									changePoint:640,
									visibleItems:2
								},
								tablet: { 
									changePoint:768,
									visibleItems: 3
								}
							}
						});
						
					});
				</script>
				<script type="text/javascript" src="js/jquery.flexisel.js"></script>
<!-- cart-js -->
	<script src="js/minicart.min.js"></script>
	<script>
		// Mini Cart
		paypal.minicart.render({
			action: '#'
		});

		if (~window.location.search.indexOf('reset=true')) {
			paypal.minicart.reset();
		}
	</script>
<!-- //cart-js --> 
<!-- video-bg -->
<script src="js/jquery.vide.min.js"></script>
<!-- //video-bg -->
<!-- Nice scroll -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- //Nice scroll -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
</body>
</html>