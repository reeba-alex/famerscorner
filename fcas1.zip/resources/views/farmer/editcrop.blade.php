







<!doctype html>
@if(session()->has('email'))
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AgroMart</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="http://127.0.0.1:8000/admin1/img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/owl.carousel.css">
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/owl.theme.css">
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/main.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/calendar/fullcalendar.print.min.css">
    <!-- tabs CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/tabs.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="http://127.0.0.1:8000/admin1/css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/vendor/modernizr-2.8.3.min.js"></script>
    <style>
    body,html { 
  /* background: url(/images/jj.jpg); no-repeat center center fixed;  */
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
/* height: 100%;
  margin: 0;
}

.bg {
  /* The image used */
  background-image: url("img_girl.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
body
    {
        background-image:url(/images/farmer.jpg);
        height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
    } */

</style>

</head>
<body class="bg">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
           <!-- <div class="sidebar-header">
                <a href="index.html"><img class="main-logo" src="img/logo/logo.png" alt="" /></a>
                <strong><img src="img/logo/logosn.png" alt="" /></strong>
            </div>-->
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a class="has-arrow" href="">
								   <i class="fa big-icon fa-home icon-wrap"></i>
								   <span class="mini-click-non">Agromart</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="true">
                                <!-- <li><a title="Add Crop Type" href="/addproduct"><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add Crop Type</span></a></li> -->
                                <li><a title="Register Crop For Sale" href="/regproduct" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Register Crop For Sale</span></a></li>
                             <li><a title="Register Farming Tool For Auction" href="/regauction" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Farming Tool For Auction</span></a></li>
                              <li><a title="View Product" href="/viewproduct" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Product</span></a></li>
                              <li><a title="View Order" href="/vieworder" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Order</span></a></li>
                              <li><a title="View Review" href="/viewreview" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Review</span></a></li>
                              <li><a title="Buy Product" href="/buy" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Buy Product</span></a></li>
                            </ul>
                        </li>

                    </ul>
                </nav>
            </div>
        </nav>
    </div>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                       <a href="/adminh"><img class="main-logo" src="img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="fa fa-bars"></i>
												</button>
                                        </div>
                                    </div>
                                   <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                          	<font color="white">	{{Session::get('email')}}</font>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                              
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
															<i class="fa fa-user adminpro-user-rounded header-riht-inf" aria-hidden="true"></i>
																<span class="admin-name">{{Session::get('email')}}</span>
															<i class="fa fa-angle-down adminpro-icon adminpro-down-arrow"></i>
														</a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                       
                                                        
                                                        <li><a href="/myprofile"><span class="fa fa-lock author-log-ic"></span>MyProfile</a>
                                                        <li><a href="/log"><span class="fa fa-lock author-log-ic"></span>Log Out</a>
                                                          </li>
                                                    </ul>
                                                </li>
                                          
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
         
            <!-- Mobile Menu end -->
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                      <!--  <div class="breadcome-heading">
                                            <form role="search" class="">
                                                <input type="text" placeholder="Search..." class="form-control">
                                                <a href=""><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>-->
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		
		
		<!-- tabs start-->
        <br><br><br>
	  <div>
	  
	  
	  
	  <img src="/images/dd.png"/>
	  
	  <div style="float:right;position:relative;border:double;border-radius:10px;background-color:orange;" > 
	  <br>
    <h3>Edit Your Crop Into Here,  For Sale..<span>&#128071;</span> </h3>
                   
               
<hr style="color:blue;">
<center>
@foreach($data1 as $user)
                <form action="/cropupdate" method="post" enctype="multipart/form-data" >
@csrf
<table>

                       
<tr><td><label><font size="3px"> Category:</font></label></td>
                     <td>  <input type="text" value="{{$user->name}}" class="form-control" disabled></td></tr>
                               <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td><label><font size="3px">Crop Name:</font></label></td>
                                  <td>   <input autocomplete="off" value="{{$user->cropvariety}}" disabled  type="text" class="form-control"id="l" placeholder="Variety name like Kashmeeri chilli" title="Variety name like Kashmeeri chilli.Fill with first letter capital." style="border-color:red;border-radius:10px;"  name="croname" title="Characters are allowed"  required onchange='Validlast1();' ></td></tr>
<script>
                                  function Validlast1() 
{
    var val = document.getElementById('l').value;

    if (!val.match(/^[A-Za-z][A-Za-z0-9" "]{0,}$/)) 
    {
        alert('Start with a Alphabet.Numbers and Characters allowed ');
		            document.getElementById('l').focus();
        return false;
    }

    return true;
}
if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('l').focus();
        return false;
    }

    return true;
}


</script>





                                  <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                                  <!-- <tr><td>&nbsp;</td><td><font color="red" size="3px" style="font-weight:bolder;">Choose date from today's date to upcoming 7 days.</font></td></tr> -->

                                 <input type="hidden" value="{{$user->id}}" name="bb">


<tr><td><label><font size="3px">Expiration Date:</font></label></td>
                                   <td>  <input type="date" class="form-control" id="j" placeholder="How many days long your crop" title="How many days long your crop" style="border-color:red;border-radius:10px;" name="date"  required onfocus='haii();'> </td></tr>
                                  
                                 
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                   <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td> <label><font size="3px">Quantity:</font></label></td>
                                  <td> <input autocomplete="off" type="number" class="form-control" id="m"placeholder="How much available on your hand for selling" title="How much available on your hand for selling" style="border-color:red;border-radius:10px;" min="1" name="qua" pattern="[1-9][0-9]" required onchange='Validlast2();' ></td>
                         <script>                               
                                  function Validlast2() 
{
    var val = document.getElementById('m').value;

    if (!val.match(/^[1-9][0-9]{0,}$/)) 
    {
        alert('Only  positive numbers  are allowed not allow 0 quantity  ');
		            document.getElementById('m').focus();
        return false;
    }

    return true;
}
if (val<0) 
    {
        alert('Only  positive numbers  are allowed not allow 0 quantity ');
		            document.getElementById('m').focus();
        return false;
    }

    return true;

</script>                                                    
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  <td><select name="quan"class="form-control" style="border-color:red;border-radius:10px;" required><option value="kg">kg</option>
                                                        <option value="g">g</option>
                                                        </select></td></tr>
                                                        <tr><td>&nbsp;</td><td>&nbsp;</td>
<tr><td> <label><font size="3px"> Price: </font></label></td>
                 </td><td><input type='number' autocomplete="off"  value="0" step="0.01" title="Currency two decimal points are allowed" pattern="^\d+(?:\.\d{1,2})?$" class="form-control" placeholder="Price of your crop" title="Price of your crop" style="border-color:red;border-radius:10px;" name="price" id="p" required onchange='price();'></td></tr>           
                 
                <!-- <input type="number"class="form-control" placeholder="0.00" required name="price" min="0" value="0" step="0.01" title="Currency" pattern="^\d+(?:\.\d{1,2})?$" onblur="
this.parentNode.parentNode.style.backgroundColor=/^\d+(?:\.\d{1,2})?$/.test(this.value)?'inherit':'red'
"> -->
                 <script>                               
                                  function price() 
{
    var val = document.getElementById('p').value;

    if (val<0)
    {
        alert('Only positive numbers  are allowed not allow 0  ');
		            document.getElementById('p').focus();
        return false;
    }

    return true;
}

</script>                  
                
                
                
                
                <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
 <!-- <tr><td>  <label><font size="3px">Image:</font></label></td>
                                   <td> <input type="file" class="form-control" placeholder="" style="border-color:red;border-radius:10px;" name="images" accept="Image/*" multiple required>  </td></tr>      
                                   <tr><td>&nbsp;</td><td>&nbsp;</td></tr> -->
   <!-- <tr><td> <label><font size="3px">Payment Facility:</font></label></td>
                                                      <td>  <select class="form-control" name="pay"style="border-color:red;border-radius:10px;" required>
                                                      <option >Providing payment facilities</option>  
                                                      <option value="Cash On Delivery">Cash On Delivery</option>
                                                      <option value="Online Payment">Online Payment</option>
                                                        <option value="Both">Both</option>
                                                        </select> </td></tr> -->
                                                        <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
 <tr><td>   <label><font size="3px">Delivery Days:</font></label>  </td>                                 
                                 <td>   <input autocomplete="off" type="text" class="form-control" id="n"  placeholder="How many days you want to deliver a crop" title="How many days you want to deliver a crop"style="border-color:red;border-radius:10px;" name="delivery" required onchange='Validlast3() ;'></td></tr>
                                 <script>                               
                                  function Validlast3() 
{
    var val = document.getElementById('n').value;

    if (!val.match(/^[1-9][0-9]{0,}$/)) 
    {
        alert('Only positive numbers  are allowed not allow 0 days ');
		            document.getElementById('n').focus();
        return false;
    }

    return true;
    if (val<0) 
    {
        alert('Only  positive numbers  are allowed not allow 0 days ');
		            document.getElementById('n').focus();
        return false;
    }

    return true;
}

</script>               
                                 
                                 
                                 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
 <tr><td><label><font size="3px">Description About Your Crop:</font></label></td>
                                   <td> <textarea class="form-control" name="des" id="o"rows="5"style="border-color:red;border-radius:10px;" cols="35" pattern="[A-Za-z][A-Za-z0-9 ]"required onchange='Validlast4();'>
                                                        </textarea>  </td></tr>
                                                       
                                                        <!-- <script>
                                  function Validlast4() 
{
    var val = document.getElementById('o').value;

    if (!val.match(/^[A-Za-z][A-Za-z0-9" ".]{0,}$/)) 
    {
        alert(' Start with a Alphabet ');
		            document.getElementById('o').focus();
        return false;
    }

    return true;
}

</script>
                                                        -->
                                                       
                                                        <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
                                                 <tr><td>&nbsp;</td>    <td>   <input type="submit" class="form-control" placeholder="" value="UPDATE" style="background-color:lightgreen;border-radius:8px;border-color:red;"> </td></tr>    
        </table>
            </form>
                                                                  
              @endforeach                                         
                                                       
                                                
                                                                    
                                                                     <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   </script>
													   
													   
                                                                    
			   </div>

                       
		<!-- jquery
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="http://127.0.0.1:8000/admin1/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/metisMenu/metisMenu.min.js"></script>
    <script src="http://127.0.0.1:8000/admin1/js/metisMenu/metisMenu-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/tab.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="http://127.0.0.1:8000/admin1/js/main.js"></script>
</body>

</html>
@endif