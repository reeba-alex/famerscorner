







<!doctype html>
@if(session()->has('email'))
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>AgroMart</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="admin1/img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/owl.carousel.css">
    <link rel="stylesheet" href="admin1/css/owl.theme.css">
    <link rel="stylesheet" href="admin1/css/owl.transitions.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/normalize.css">
    <!-- meanmenu icon CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/meanmenu.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/main.css">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="admin1/css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="admin1/css/calendar/fullcalendar.print.min.css">
    <!-- tabs CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/tabs.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="admin1/css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="admin1/js/vendor/modernizr-2.8.3.min.js"></script>
    <style>
    body,html { 
  /* background: url(/images/jj.jpg); no-repeat center center fixed;  */
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
/* height: 100%;
  margin: 0;
}

.bg {
  /* The image used */
  background-image: url("img_girl.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
body
    {
        background-image:url(/images/farmer.jpg);
        height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
    } */

</style>

</head>
<body class="bg">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
           <!-- <div class="sidebar-header">
                <a href="index.html"><img class="main-logo" src="img/logo/logo.png" alt="" /></a>
                <strong><img src="img/logo/logosn.png" alt="" /></strong>
            </div>-->
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                       
                            <a class="has-arrow" href="/farmer">
								   <!-- <i class="fa big-icon fa-home icon-wrap"></i> -->
								   <span class="mini-click-non">Agromart</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="true">
                                <!-- <li><a title="Add Crop Type" href="/addproduct"><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add Crop Type</span></a></li> -->
                                <li><a title="Register Crop For Sale" href="/regproduct" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Register Crop For Sale</span></a></li>
                             <li><a title="Register Farming Tool For Auction" href="/regauction" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Farming Tool For Auction</span></a></li>
                              <li><a title="View Product" href="/viewproduct" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Product</span></a></li>
                              <li><a title="View Order" href="/vieworder" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Order</span></a></li>
                              <li><a title="View Review" href="/viewreview" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Review</span></a></li>
                              <li><a title="Buy Product" href="/buy" ><i class="fa fa-bullseye sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Buy Product</span></a></li>
                            </ul>
                        </li>

                    </ul>
                </nav>
            </div>
        </nav>
    </div>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                       <a href="/adminh"><img class="main-logo" src="img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="fa fa-bars"></i>
												</button>
                                        </div>
                                    </div>
                                   <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                          	<font color="white">	{{Session::get('email')}}</font>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                              
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
															<i class="fa fa-user adminpro-user-rounded header-riht-inf" aria-hidden="true"></i>
																<span class="admin-name">{{Session::get('email')}}</span>
															<i class="fa fa-angle-down adminpro-icon adminpro-down-arrow"></i>
														</a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                       
                                                        
                                                        <li><a href="/myprofile"><span class="fa fa-lock author-log-ic"></span>MyProfile</a>
                                                        <li><a href="/log"><span class="fa fa-lock author-log-ic"></span>Log Out</a>
                                                          </li>
                                                    </ul>
                                                </li>
                                          
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
         
            <!-- Mobile Menu end -->
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                      <!--  <div class="breadcome-heading">
                                            <form role="search" class="">
                                                <input type="text" placeholder="Search..." class="form-control">
                                                <a href=""><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>-->
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
		
		
		<!-- tabs start-->
        <div class="admintab-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="tab-content-details shadow-reset" style="position:relative;left:100px;">
                        <center> <p><font color="red"style="font-size:30px;">****Crop Order Details****</font></p></center>
                            <!-- <a href="/category3">  <button type="button" class="btn btn-primary" > -->
<!-- <i class="glyphicon glyphicon-plus-sign">Add New</i></button></a> -->
<p>@if(\Session::has('success'))
						<div class="alert alert-success">
					<ul>
					<li>
					{!! \Session::get('success')!!}
					</li>
					</ul>
					</div>
					@endif</p>
                            
                            <div class="product-status-wrap" style="font-weight:bolder;font-color:white;background-color:lightgreen;">
                            
                            @if(count($a)>0)
					<table>
	                  	  	 
	                  	  	  <hr>
                             
                              <tr>
                              <td><font color="red">Customer Name</font></td>
                                  <td><font color="red">Crop Name</font></td>
                               <td><font color="red">Customer Email</font></td>
                               <td><font color="red">Customer Address</font></td>
                              <td><font color="red">Total</font></td>
                                  <td ><font color="red">Status</font></td>
								  
                                
                              </tr>
                              </thead>
                              <tbody>
							  <form method="post">
							  @csrf
							  @foreach($a as $user)	
                              <tr>
                              <td>{{ $d }}</td>

                                  <td>{{ $user->name }}</td>

<td>{{ $user->email }}</td>
<td>{{ $c }}</td>

<td>{{ $user->total }}</td>
                                  
                                  <td>               
							  
									 


                                  {{ $user->statuss }}
                                      
									  
                                      </td>               
							  
                                      <td>               
							  
									 



                                      <a href="{{route('paid.edit',$user->id)}}">
									  PAID
									  </a>
                                      </td>  
                                     
                                
                              </tr>
							  
                             @endforeach
                              </tbody>
                          </table>
				
				
				@else
				
				
				
					<font color="red" style="size:20px;">NO NEW ORDER For Crop.</font>
				
				@endif
        </div>
                    </div>
                </div>
        <br>
        <div class="admintab-area mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="tab-content-details shadow-reset" style="position:relative;left:100px;">
                        <center> <p><font color="red"style="font-size:30px;">****Auction Tool Order Details****</font></p></center>
                            <!-- <a href="/category3">  <button type="button" class="btn btn-primary" > -->
<!-- <i class="glyphicon glyphicon-plus-sign">Add New</i></button></a> -->
<p>@if(\Session::has('success'))
						<div class="alert alert-success">
					<ul>
					<li>
					{!! \Session::get('success')!!}
					</li>
					</ul>
					</div>
					@endif</p>
                            
                            <div class="product-status-wrap" style="font-weight:bolder;font-color:white;background-color:pink;">
  
        @if(count($pay)>0)
					<table>
	                  	  	 
	                  	  	  <hr>
                             
                              <tr>
                              <td><font color="red">Farmer Email</font></td>
                                  <td><font color="red">Tool Name</font></td>
                               
                              <td><font color="red">Amount</font></td>
                                  <td ><font color="red">Status</font></td>
								  
                                
                              </tr>
                              </thead>
                              <tbody>
							  <form method="post">
							  @csrf
							  @foreach($pay as $u)	
                              <tr>
                              

                                  <td>{{ $u->memberid }}</td>

<td>{{ $u->toolname }}</td>


<td>{{ $u->amount }}</td>
                                  
                                  <td>               
							  
									 


                                  {{ $u->stat }}
                                      
									  
                                      </td>               
							  
                                      <td>               
							  
									 



                                      <a href="{{route('delivered.edit',$u->id)}}">
									  DELIVERED
									  </a>
                                      </td>  
                                     
                                
                              </tr>
							  
                             @endforeach
                              </tbody>
                          </table>
				
				
				@else
				
				
				
					<font color="red" style="size:20px;">NO NEW ORDER FOR FARMING TOOL.</font>
				
				@endif

        </div>
                    </div>
                </div>
                       
                <!-- <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="admintab-wrap mg-t-30">
                            <ul class="nav nav-tabs custom-menu-wrap custon-tab-menu-style1">
                                <li class="active"><a data-toggle="tab" href="#TabProject"><span class="adminpro-icon adminpro-analytics tab-custon-ic"></span>Tab Project</a>
                                </li>
                                <li><a data-toggle="tab" href="#TabDetails"><span class="adminpro-icon adminpro-analytics-arrow tab-custon-ic"></span>Tab Details</a>
                                </li>
                                <li><a data-toggle="tab" href="#TabPlan"><span class="adminpro-icon adminpro-analytics-bridge tab-custon-ic"></span>Tab Plan</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="TabProject" class="tab-pane in active animated flipInX custon-tab-style1">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                    <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                                    <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                </div>
                                <div id="TabDetails" class="tab-pane animated flipInX custon-tab-style1">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                    <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                                </div>
                                <div id="TabPlan" class="tab-pane animated flipInX custon-tab-style1">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                    <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries. </p>
                                    <p>the leap into electronic typesetting, remaining essentially unchanged.</p>
                                </div>
                            </div>
                        </div>
                    </div> -->
                                                  
                    <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   </script>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="admintab-wrap mg-t-30">
                            <ul class="nav nav-tabs custom-menu-wrap custon-tab-menu-style1 tab-menu-right">
                                <!-- <li class="active"><a data-toggle="tab" href="#TabProject2"><span class="adminpro-icon adminpro-analytics tab-custon-ic"></span>They Say</a>
                                </li> -->
                                <!-- <li><a data-toggle="tab" href="#TabDetails2"><span class="adminpro-icon adminpro-analytics-arrow tab-custon-ic"></span>Tab Details</a>
                                </li>
                                <li><a data-toggle="tab" href="#TabPlan2"><span class="adminpro-icon adminpro-analytics-bridge tab-custon-ic"></span>Tab Plan</a>
                                </li> -->
                            </ul>
                            <!-- <div class="tab-content">
                                <div id="TabProject2" class="tab-pane in active animated flipInY custon-tab-style1">
                                <img src="images/team1.jpg" alt="" class="img-r">
									<h4>Ram Kumar</h4>
									<span>FARMER 1</span>
									<p>I am cultivating banana and coconut. AgroMart has crossed the boundaries through the website. A lot of farmers and traders contact me by AgroMart and receive herbal advice. </p>
                                    <img src="images/team2..jpg" alt="" class="img-r">
										<h4>Joseph </h4>
										<span>FARMER 2</span>
										<p>The service of AgroMart website can be called Net Marketing. Effective website for all information of farmers. Congrats on your initiative.</p>
                                
                                </div>
                                <div id="TabDetails2" class="tab-pane animated flipInY custon-tab-style1">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                    <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                                </div>
                                <div id="TabPlan2" class="tab-pane animated flipInY custon-tab-style1">
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                                    <p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries. </p>
                                    <p>the leap into electronic typesetting, remaining essentially unchanged.</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tabs End-->
		</div>
		<!-- jquery
		============================================ -->
    <script src="admin1/js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="admin1/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="admin1/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="admin1/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="admin1/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="admin1/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="admin1/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="admin1/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="admin1/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="admin1/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="admin1/js/metisMenu/metisMenu.min.js"></script>
    <script src="admin1/js/metisMenu/metisMenu-active.js"></script>
    <!-- tab JS
		============================================ -->
    <script src="admin1/js/tab.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="admin1/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="admin1/js/main.js"></script>
</body>

</html>
@endif