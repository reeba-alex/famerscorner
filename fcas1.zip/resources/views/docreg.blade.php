<html>
<head><title>doc</title></head>
<body>
{{Session::get('name')}}
<form action="/doc" method="post" enctype="multipart/form-data">
 {{ csrf_field() }}
photo:<input type="file" name="img1" id="img1"><br><br>
aadharcard:<input type="file" name="img2" id="img2"><br><br>
taxreceipt:<input type="file" name="img3"><br><br>
badythacer:<input type="file" name="img4"><br><br>
kaivashamcer:<input type="file" name="img5"><br><br>
plan:<input type="file" name="img6"><br><br>
aaharam:<input type="file" name="img7"><br><br>
<input type="submit" name="submit" value="SUBMIT">
<a href="/log" >LOGOUT</a>



</form>
</body>



</html>
