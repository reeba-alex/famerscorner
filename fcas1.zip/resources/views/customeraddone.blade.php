<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
   <!DOCTYPE html>
   @if(session()->has('email'))
<html lang="zxx">
   <head>
      <title>AgroMart</title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="Toys Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
      <script>
         addEventListener("load", function () {
         	setTimeout(hideURLbar, 0);
         }, false);
         
         function hideURLbar() {
         	window.scrollTo(0, 1);
         }
      </script>
      <!--//meta tags ends here-->
      <!--booststrap-->
      <link href="http://127.0.0.1:8000/index/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
      <!--//booststrap end-->
      <!-- font-awesome icons -->
      <link href="http://127.0.0.1:8000/index/css/fontawesome-all.min.css" rel="stylesheet" type="text/css" media="all">
      <!-- //font-awesome icons -->
      <!--Shoping cart-->
      <link rel="stylesheet" href="http://127.0.0.1:8000/index/css/shop.css" type="text/css" />
      <!--//Shoping cart-->
      <!--checkout-->
      <link rel="stylesheet" type="text/css" href="http://127.0.0.1:8000/index/css/checkout.css">
      <!--//checkout-->
      <!--stylesheets-->
      <link href="http://127.0.0.1:8000/index/css/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//stylesheets-->
      <link href="//fonts.googleapis.com/css?family=Sunflower:500,700" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
   </head>
   <body>
      <!--headder-->
      <div class="header-outs" id="home" >
      <div class="header-bar">
         <div class="info-top-grid">
            <div class="info-contact-agile" >
               <ul  >
                <!--  <li>
                     <span class="fas fa-phone-volume"></span>
                     <p>+(000)123 4565 32</p>
                  </li>
                  <li>
                     <span class="fas fa-envelope"></span>
                     <p><a href="mailto:info@example.com">info@example1.com</a></p>
                  </li>
                  <li>
                  </li>-->
				    <li >
                <a href="" class="nav-link" style="font-weight:bolder;"data-toggle="modal" data-target="#exampleModalreg"><font color="white">Sell With Us </font></a>
                     </li>
					 
					<li >
                        <a href="" class="nav-link" style="position:relative;left:710px;font-weight:bolder;" data-toggle="modal" data-target="#exampleModal1"><font color="white">Buy With Us</font></a>
                     </li> 
					  <!-- <li >
                        <a href="" class="nav-link"style="position:relative;left:730px;font-weight:bolder;"data-toggle="modal" data-target="#exampleModal"><font color="white">Login</font></a>
                     </li> -->
                     <li>
                     <a href="/log"class="nav-link"style="position:relative;left:730px;font-weight:bolder;">Logout</a>
                     </li>
                     <li>
                     <a href="/log"><font color="white">Sign In Us: {{Session::get('email')}}</font></a>
                     </li>
                  </ul>
              
               </ul>
            </div>
         </div>
            <div class="container-fluid">
               <div class="hedder-up row">
                  <div class="col-lg-3 col-md-3 logo-head">
                     <h1><a class="navbar-brand" href="/buy">AgroMart</a></h1>
                  </div>
                  <div class="col-lg-5 col-md-6 search-right">
                     <!-- <form class="form-inline my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search">
                        <button class="btn" type="submit">Search</button>
                     </form> -->
                  </div>
                  <div class="col-lg-4 col-md-3 right-side-cart">
                     <div class="cart-icons">
                        <!-- <ul>
                           <li>
                              <span class="far fa-heart"></span>
                           </li> -->
                           <!-- <li>
                              <button type="button" data-toggle="modal" data-target="#exampleModal"> <span class="far fa-user"></span></button>
                           </li>
                           <li class="toyscart toyscart2 cart cart box_1">
                              <form action="#" method="post" class="last">
                                 <input type="hidden" name="cmd" value="_cart">
                                 <input type="hidden" name="display" value="1">
                                 <button class="top_toys_cart" type="submit" name="submit" value="">
                                 <span class="fas fa-cart-arrow-down"></span>
                                 </button>
                              </form>
                           </li> 
                        </ul>-->
                     </div>
                  </div>
               </div>
            </div>
          <!--  <nav class="navbar navbar-expand-lg navbar-light">
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
               <span class="navbar-toggler-icon"></span>
               </button>
               <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                  <ul class="navbar-nav ">
                     <li class="nav-item active">
                        <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
                     </li>
                     <li class="nav-item">
                        <a href="about.html" class="nav-link">About</a>
                     </li>
                     <li class="nav-item">
                        <a href="service.html" class="nav-link">Service</a>
                     </li>
                     <li class="nav-item active">
                        <a href="shop.html" class="nav-link">Shop Now</a>
                     </li>
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Pages
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                           <a class="nav-link" href="icon.html">404 Page</a>
                           <a class="nav-link " href="typography.html">Typography</a>
                        </div>
                     </li>
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Product
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                           <a class="nav-link" href="product.html">Kids Toys</a>
                           <a class="nav-link " href="product.html">Dolls</a>
                           <a class="nav-link " href="product.html">Key Toys</a>
                           <a class="nav-link " href="product.html">Boys Toys</a>
                        </div>
                     </li>
                     <li class="nav-item">
                        <a href="contact.html" class="nav-link">Contact</a>
                     </li>
                  </ul>
               </div>
            </nav>-->
         </div>
		  </div>
         <!--//headder-->
         <!-- banner -->
         <div class="inner_page-banner one-img">
         </div>
         <!-- short -->
         <div class="using-border py-3">
            <div class="inner_breadcrumb  ml-4">
               <ul class="short_ls">
               <li class="nav-item active">
                        <a class="nav-link" href="/buy"><font color="white" style="font-weight:bolder;">Home</font> <span class="sr-only">(current)</span></a>
                     </li>
                     <li class="nav-item">
                        <a href="/about" class="nav-link"><font color="white"style="font-weight:bolder;">About</font></a>
                     </li>
                     <li class="nav-item">
                        <a href="" class="nav-link" data-toggle="modal" data-target="#exampleModal2"><font color="white"style="font-weight:bolder;">Shop Now</font></a>
                     </li>
                     <li class="nav-item">
                        <a href="/gallery" class="nav-link"><font color="white"style="font-weight:bolder;">Gallery</font></a>
                     </li>
					 </font></li>
               </ul>
            </div>
         </div>
         <!-- //short-->
         <!--Checkout-->  
         <!-- //banner -->
         <!-- top Products -->
      
         
                     <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   
													   
													   
													   </script>
                     <div class="checkout-left" style="position:relative;left:50px;">
                     
                        <div class="col-md-4 checkout-left-basket" >
                           <h4>Confirm to basket</h4>
                           @if(count($data)>0)
                           @foreach($data as $user1)
                           <ul>
                           @if($user1->sta=="0")
                              <li>{{$user1->cropvariety}} <i>-</i> <span>₹{{$user1->price}} </span></li>
                              @endif

                              @endforeach
                        @endif
                              <li>Total <i>-</i><span>₹{{$total}}</span></li>
                           </ul>
                        </div>
                        
                    @foreach($cus as $bb)
                        <div class="col-md-8 address_form" style="width:500px;position:relative;right:10px;float:left;">
                           <h4>Add a new Details</h4>
                           <form action="/address" method="post" class="creditly-card-form agileinfo_form">
                           @csrf
                              <section class="creditly-wrapper wrapper">
                                 <div class="information-wrapper">
                                    <div class="first-row form-group">
                                       <div class="controls">
                                          <label class="control-label">Full name: </label>
                                          <input class="billing-address-name form-control" type="text" value="{{$bb->name}}" name="name" id="firstname"placeholder="Full name" onchange='Validlast1();' required>
                                       </div>
									   					     <script>		
function Validlast1() 
{
    var val = document.getElementById('firstname').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet ');
		            document.getElementById('firstname').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('firstname').focus();
        return false;
    }


    return true;
}

</script>     
                                       <div class="card_number_grids">
                                          <div class="card_number_grid_left">
                                             <div class="controls">
                                                <label class="control-label">Mobile number:</label>
                                                <input class="form-control" type="number" name="no" value="{{$bb->ph}}"id="c" placeholder="Mobile number" onchange='Validat();' required>
                                             </div>
                                          </div>
										  <script>		
function Validat() 
{
    var val = document.getElementById('c').value;

    if (!val.match(/^[6-9][0-9]{9,9}$/))
    {
        alert('Only Numbers are allowed start with 6,7,8,9 and contain 10 digits');
	
		
        document.getElementById('c').focus();
        return false;
    }

    return true;
}

</script>
                                          <div class="card_number_grid_right">
                                             <div class="controls">
                                                <label class="control-label">Address: </label>
                                                <input class="form-control" type="text" name="add" placeholder="Address" value="{{$bb->addr}}" required>
                                                <!-- <textarea row="80" column="20" name="add">
                                                </textarea> -->
                                             </div>
                                          </div>
                                          <div class="clear"> </div>
                                       </div>
                                       <div class="controls">
                                          <label class="control-label">PinCode: </label>
                                          <input  type="text" class="form-control"name="pin" id="pin"value="{{$bb->pin}}" placeholder="Pin Number" onchange='validate0();'>
                                       </div>
									    <script>
                    function validate0() 
{
    var val = document.getElementById('pin').value;

    if (!val.match(/^\d{6}$/)) 
    {
        alert('Only 6 digit number allowed');
        document.getElementById('pin').focus();
        return false;
    }

    return true;
}

</script>
                                       <div class="controls">
                                          <label class="control-label">Address type: </label>
                                          <select class="form-control option-w3ls" name="type" style="height:60px;"required>
                                             <option>Office</option>
                                             <option>Home</option>
                                             <option>Commercial</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="controls">
                                          
                                          <input class="submit check_out" type="submit" value="Delivery to this Address" style="width:10px;">
                                       </div>
                                    <!-- <button >Delivery to this Address</button> -->
                                 </div>
                              </section>
                           </form>
                           <!-- <form action="/bank" method="post">
                           @csrf
                           <div class="checkout-right-basket">
                           <input type="submit" value="Make a Payment"> 
                              
                           </div>
                           </form> -->
                           <br>
                           @foreach($data as $user1)
                           <div  style="background-color:black;height:30px;width:150px;border-radius:10px;float:right">
                     <a href="{{route('payment1.edit',$user1->id)}}" ><font  style="font-weight:bolder;"> Make Payment</font></a>
                    </div> 
@endforeach
                        </div>
                        <div class="clearfix"> </div>
                        <div class="clearfix"></div>
                     </div>
                  </div>
               </div>
               <!-- //top products -->
            </div>
			@endforeach
      </section>
      <!--subscribe-address
      <section class="subscribe">
         <div class="container-fluid">
         <div class="row">
            <div class="col-lg-6 col-md-6 map-info-right px-0">
               <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3150859.767904157!2d-96.62081048651531!3d39.536794757966845!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1408111832978"> </iframe>
            </div>
            <div class="col-lg-6 col-md-6 address-w3l-right text-center">
               <div class="address-gried ">
                  <span class="far fa-map"></span>
                  <p>25478 Road St.121<br>USA New Hill
                  <p>
               </div>
               <div class="address-gried mt-3">
                  <span class="fas fa-phone-volume"></span>
                  <p> +(000)123 4565<br>+(010)123 4565</p>
               </div>
               <div class=" address-gried mt-3">
                  <span class="far fa-envelope"></span>
                  <p><a href="mailto:info@example.com">info@example1.com</a>
                     <br><a href="mailto:info@example.com">info@example2.com</a>
                  </p>
               </div>
            </div>
         </div>
		 </div>
      </section>-->
      <!--//subscribe-address
      <section class="sub-below-address py-lg-4 py-md-3 py-sm-3 py-3">
         <div class="container py-lg-5 py-md-5 py-sm-4 py-3">
            <h3 class="title clr text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">Get In Touch Us</h3>
            <div class="icons mt-4 text-center">
               <ul>
                  <li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
                  <li><a href="#"><span class="fas fa-envelope"></span></a></li>
                  <li><a href="#"><span class="fas fa-rss"></span></a></li>
                  <li><a href="#"><span class="fab fa-vk"></span></a></li>
               </ul>
               <p class="my-3">velit sagittis vehicula. Duis posuere 
                  ex in mollis iaculis. Suspendisse tincidunt
                  velit sagittis vehicula. Duis posuere 
                  velit sagittis vehicula. Duis posuere 
               </p>
            </div>
            <div class="email-sub-agile">
               <form action="#" method="post">
                  <div class="form-group sub-info-mail">
                     <input type="email" class="form-control email-sub-agile" placeholder="Email">
                  </div>
                  <div class="text-center">
                     <button type="submit" class="btn subscrib-btnn">Subscribe</button>
                  </div>
               </form>
            </div>
         </div>
      </section>-->
      <!--//subscribe-->
      <!-- footer 
      <footer class="py-lg-4 py-md-3 py-sm-3 py-3 text-center">
         <div class="copy-agile-right">
            <p> 
               © 2018 Toys-Shop. All Rights Reserved | Design by <a href="http://www.W3Layouts.com" target="_blank">W3Layouts</a>
            </p>
         </div>
      </footer>-->
      <!-- //footer -->
      <!-- Modal 1-->
      <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Choose Your Desired Category</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <div class="register-form">

                  @if(count($cat)>0)


@foreach($cat as $us)

<a href="{{route('buy1.edit',$us->id)}}"><font color="red">{{$us->name}}</font></a><br>
@endforeach
@endif



                     
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Register With Us A Customer</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <div class="register-form">
                     <form action="/data1" class="oh-autoval-form" method="post" onsubmit="return" id="register">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="text"  name="firstname" id="firstname" placeholder="Name" autocomplete="off" value="{{ old('firstname') }}"class="form-control" style="text-transform:capitalize;"title="Only Alphabet are allowed" pattern="[a-zA-Z\s]+" required >
                                                       
                                                      		   
													    		   
                                             
																
                                                
                                                       <input type="email" class="form-control "  name="email" id="e1" style="text-transform:lowercase;" placeholder="Email" autocomplete="off" required onChange='Validem1();'>
													   
													   <script>		
function Validem1() 
{
    var val = document.getElementById('e1').value;

    if (!val.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) 
    {
        alert('Incorrect Email');
		
		     document.getElementById('e1').value = "";
        return false;
    }

    return true;
}

</script>
													   
													   <input type="password" class="form-control"  name="password" id="pass" placeholder="Password" onchange='validate01();' autocomplete="off" required>
													  
                                                                    <script>
                    function validate01() 
{
     var val = document.getElementById('pass').value;

if (!val.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/)) 
{
   alert('Password should contain atleast a capital letter and small letter and a Number with length atleast 6 ');
      
           document.getElementById('pass').focus();
    return false;
}

return true;
}


</script>
          
                                                                   
                                                                   
                                                                   
                                                                    <input type="password" class="form-control av-password" name="cpassword" id="cpass"placeholder=" Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars. &&&& Similar to password" autocomplete="off" onChange='check1();'>
                                                       
													   <script>
													   
	function check1(){
			if(document.getElementById("cpass").value!=document.getElementById("pass").value)
			{
			alert('Doesnot match with password');
				
		            document.getElementById('cpass').value = "";
            }
		else{
			alert(' matched');
			}}
	</script>							   
													
													   <input type="submit" class="form-control" name="submit" value="Submit Button">
													   <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   
													   
													   
													   </script>
                                                  </form>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Login</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <div class="register-form">
                     <form action="#" method="post">
                        <div class="fields-grid">
                           <div class="styled-input">
                              <input type="text" placeholder="Your Name" name="Your Name" required="">
                           </div>
                           <div class="styled-input">
                              <input type="email" placeholder="Your Email" name="Your Email" required="">
                           </div>
                           <div class="styled-input">
                              <input type="password" placeholder="password" name="password" required="">
                           </div>
                           <button type="submit" class="btn subscrib-btnn">Login</button>
                        </div>
                     </form>
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade" id="exampleModalreg" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Choose Your Desired Category</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                  </button>
               </div>
               <div class="modal-body">
                  <div class="register-form">

                  <br>
&nbsp;&nbsp;&nbsp;Already I Have An Account&nbsp;<a href="#" data-toggle="modal" data-target="#exampleModal" >Login?</a>	
<br>  
	  <form action="/data"  method="post" name="register" class="oh-autoval-form"  enctype="multipart/form-data">
									@csrf
                                             
                                             <table><br>  
											 <div>
											 <tr><td><label>FirstName:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"value="{{ old('fname') }}"  name="fname" id="firstname" class="form-control" placeholder="First Name" autocomplete="off"  title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onchange='Validlast1();'>
											 
											 </td></tr></div>
											<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Last Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"value="{{ old('lname') }}" name="lname"class="form-control" id="l" placeholder="Last Name"autocomplete="off"  title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onchange='Validlast();'>
											</td></tr> </div>  <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Email Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="email"id="e" style="text-transform:lowercase;"class="form-control" name="email" placeholder="Email"autocomplete="off" required onchange='Validem();'>
								            </td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td><label> Mobile Number:<label>&nbsp;	&nbsp;&nbsp; </td> <td> <input type="telephone"class="form-control"   value="{{ old('phone') }}"name="phone" id="c" placeholder="Mobile Phone" autocomplete="off" required onchange='Validat();' >

											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											  <div>
											<tr><td> <label>Profile Photo:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file"value="{{ old('fname') }}"  name="pic" id="fileChooser" placeholder="profile pic" class="form-control"accept="image/*" onchange='ValidateFileUpload();' required  >
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>House Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"value="{{ old('hname') }}" name="hname" id="hname" placeholder="House Name" class="form-control"autocomplete="off"  title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onChange='validate();'>
										</td></tr>	 </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Country:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <select name="country"value="{{ old('country') }}" id="country" autocomplete="off" placeholder="country"class="form-control"  av-message="required" required>
                                                       <option value="">Select Country</option>
                        
							 <option value="India">India</option>
						
                    </select>
								          </td></tr>   </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
										<tr><td>	<label> State:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label></td>	&nbsp;   
										<td><select name="state" value="{{ old('state') }}" id="state"  autocomplete="off" placeholder="state" class="form-control" required>
                                                       <option value="">Select State</option>
                        
							 <option value="kerala">Kerala</option>
						
                    </select>
										</td></tr>	 </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
										<tr><td>	 <label>District:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <select id="state" value="{{ old('district') }}" name=district class="form-control" required> 
                       <option value="">Select District</option>                                         
                      @foreach($states as $key => $state)
                      
							 <option value="{{$state}}">{{$state}}</option>
							  @endforeach
                                     </select>
										</td></tr>	 </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>
											 Panchayath Name:</label>&nbsp;</td>
											<td> <input type="text"  av-message="must be letter also required" value="{{ old('pan') }}" name="pan" class="form-control"id="pan"placeholder="Panchayath Name"autocomplete="off" title="Only alphabets are allowed and Start with a Alphabet" required pattern="[a-zA-Z]+" onchange='validate1();'>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Pincode: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="text"  autocomplete="off"  av-message="6 gigit nuber& required"name="pin"  id="pin" class="form-control"placeholder="Pin Number" title="Only six digit Number" required pattern="[1-9][0-9]{5}+$" onchange='validate0();' >
											
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Password:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars." class="form-control"id="pass" name="password" placeholder="Password" onchange='validate01();' required>
													
					
                                                                   
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Confirm Password:</label>&nbsp;</td>
											<td> <input type="password"  name="cpassword" id="cpass" class="form-control" placeholder="Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.Similar to password" onChange='check();' required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label><font color="yellow">Document Upload**</font></label>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Aadhar Card:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file" placeholder="Aadhar Card" name="img1"class="form-control" accept="application/pdf, application/vnd.ms-excel" required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Tax Receipt:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file" placeholder="Tax" name="img2" class="form-control"accept="application/pdf, application/vnd.ms-excel" required>
                                           </td></tr>  </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											  <div>
											<tr><td> <label>Plan:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file"  placeholder="plan" name="img3"class="form-control" accept="application/pdf, application/vnd.ms-excel" required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 <div>
											<tr><td> <label>Aadharam:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>&nbsp;</td>
											<td> <input type="file"  placeholder="Aadharam" name="img4"class="form-control" accept="application/pdf, application/vnd.ms-excel" required>
											</td></tr> </div><tr><td>&nbsp;</td><td>&nbsp;</td></tr>
											 
        
       

											
											
                                            
													     <script>		
function Validlast1() 
{
    var val = document.getElementById('firstname').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet ');
		            document.getElementById('firstname').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('firstname').focus();
        return false;
    }


    return true;
}

</script>     

                              <script>		
function Validlast() 
{
    var val = document.getElementById('l').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet');
        document.getElementById('l').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('l').focus();
        return false;
    }

    return true;
}

</script>             



          
          <script>		
function Validem() 
{
    var val = document.getElementById('e').value;

    if (!val.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/)) 
    {
        alert('Incorrect Email.Use email format');
		
		    document.getElementById('e').focus();
        return false;
    }

    return true;
}

</script>													   
													   
                                                                 

<script>		
function Validat() 
{
    var val = document.getElementById('c').value;

    if (!val.match(/^[6-9][0-9]{9,9}$/))
    {
        alert('Only Numbers are allowed start with 6,7,8,9 and contain 10 digits');
	
		
        document.getElementById('c').focus();
        return false;
    }

    return true;
}

</script>
													   
												
                                                                 
                                                                    <SCRIPT type="text/javascript">
    function ValidateFileUpload() {
        var fuData = document.getElementById('fileChooser');
        var FileUploadPath = fuData.value;

//To check if user upload any file
        if (FileUploadPath == '') {
            alert("Please upload an image");

        } else {
            var Extension = FileUploadPath.substring(
                    FileUploadPath.lastIndexOf('.') + 1).toLowerCase();

//The file uploaded is an image

if (Extension == "gif" || Extension == "png" || Extension == "bmp"
                    || Extension == "jpeg" || Extension == "jpg") {

// To Display
                if (fuData.files && fuData.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#blah').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(fuData.files[0]);
                }

            } 

//The file upload is NOT an image
else {
                alert("Photo only allows file types of GIF, PNG, JPG, JPEG and BMP. ");
                document.getElementById('fileChooser').focus();
            }
        }
    }
</SCRIPT>
													
										
												

												
												<script>		
function validate() 
{
    var val = document.getElementById('hname').value;

    if (!val.match(/^[0-9a-zA-Z ]+$/)) 
    {
        alert('Only alphabets and numbers are allowed');
        document.getElementById('hname').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('hname').focus();
        return false;
    }

    return true;
}

</script>
												
												
												
												
												
																	
													   
													   
													   
													   
													   
											
                                                                    <script>		
function validate1() 
{
    var val = document.getElementById('pan').value;

    if (!val.match(/^[a-zA-Z ]+$/)) 
    {
        alert('Only alphabets are allowed');
        document.getElementById('pan').focus();
        return false;
    }
    if (!val.match(/^[A-Z]/)) 
    {
        alert(' Start with Capital letter ');
		            document.getElementById('pan').focus();
        return false;
    }

    return true;
}

</script>
                                                                    
                                                                   
                    <script>
                    function validate0() 
{
    var val = document.getElementById('pin').value;

    if (!val.match(/^\d{6}$/)) 
    {
        alert('Only 6 digit number allowed');
        document.getElementById('pin').focus();
        return false;
    }

    return true;
}

</script>
            


                    

                                                                    <script>
                    function validate01() 
{
     var val = document.getElementById('pass').value;

if (!val.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/)) 
{
   alert('Password should contain atleast a capital letter and small letter and a Number with length atleast 6 ');
      
           document.getElementById('pass').focus();
    return false;
}

return true;
}


</script>
          
                                    
                                                 
                                                 
                                                 
                                                 
                                               
                                                            <script>	      
											function check(){
			if(document.getElementById("cpass").value!=document.getElementById("pass").value)
			{
			alert('Doesnot match with password');
				
               document.getElementById('cpass').focus();
            }
                                                       }
	
   </script>	
    <tr>     <td> <input type="submit"style="width:200px;background-color:lightgreen;" class="form-control" name="submit" value="Submit">
													  </td><tr>
                                                                  
                                                       
                                                       
                                                
                                                                    
                                                                     <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   </script>
													   
													   
                                                </table>		   
                                                  </form>



                     
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>

      <!-- //Modal 1-->
      <!--js working-->
      <script src='http://127.0.0.1:8000/index/js/jquery-2.2.3.min.js'></script>
      <!--//js working-->
      <!-- cart-js -->	
      <script src="http://127.0.0.1:8000/index/js/minicart.js"></script>
      <script>
         toys.render();
         
         toys.cart.on('toys_checkout', function (evt) {
         	var items, len, i;
         
         	if (this.subtotal() > 0) {
         		items = this.items();
         
         		for (i = 0, len = items.length; i < len; i++) {}
         	}
         });
      </script>
      <!--// cart-js -->
      <!--quantity-->
      <script>
         $('.value-plus').on('click', function () {
         	var divUpd = $(this).parent().find('.value'),
         		newVal = parseInt(divUpd.text(), 10) + 1;
         	divUpd.text(newVal);
         });
         
         $('.value-minus').on('click', function () {
         	var divUpd = $(this).parent().find('.value'),
         		newVal = parseInt(divUpd.text(), 10) - 1;
         	if (newVal >= 1) divUpd.text(newVal);
         });
      </script>
      <!--quantity-->
      <!--closed-->
      <script>
         $(document).ready(function (c) {
         	$('.close1').on('click', function (c) {
         		$('.rem1').fadeOut('slow', function (c) {
         			$('.rem1').remove();
         		});
         	});
         });
      </script>
      <script>
         $(document).ready(function (c) {
         	$('.close2').on('click', function (c) {
         		$('.rem2').fadeOut('slow', function (c) {
         			$('.rem2').remove();
         		});
         	});
         });
      </script>
      <script>
         $(document).ready(function (c) {
         	$('.close3').on('click', function (c) {
         		$('.rem3').fadeOut('slow', function (c) {
         			$('.rem3').remove();
         		});
         	});
         });
      </script>
      <!--//closed-->
      <!-- start-smoth-scrolling -->
      <script src="http://127.0.0.1:8000/index/js/move-top.js"></script>
      <script src="http://127.0.0.1:8000/index/js/easing.js"></script>
      <script>
         jQuery(document).ready(function ($) {
         	$(".scroll").click(function (event) {
         		event.preventDefault();
         		$('html,body').animate({
         			scrollTop: $(this.hash).offset().top
         		}, 900);
         	});
         });
      </script>
      <!-- start-smoth-scrolling -->
      <!-- here stars scrolling icon -->
      <script>
         $(document).ready(function () {
         
         	var defaults = {
         		containerID: 'toTop', // fading element id
         		containerHoverID: 'toTopHover', // fading element hover id
         		scrollSpeed: 1200,
         		easingType: 'linear'
         	};
         	$().UItoTop({
         		easingType: 'easeOutQuart'
         	});
         
         });
      </script>
      <!-- //here ends scrolling icon -->
      <!--bootstrap working-->
      <script src="http://127.0.0.1:8000/index/js/bootstrap.min.js"></script>
      <!-- //bootstrap working-->
   </body>
</html>
@endif