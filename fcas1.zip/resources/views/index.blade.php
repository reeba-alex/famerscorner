<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">
<head>
<title>AgroMart</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="prezzie Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="css/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=Tangerine:400,700" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>




</head>
<body>
<!-- banner -->
<div class="banner_top" id="home">
	<div data-vide-bg ="video/gift">
		<div class="center-container">
			<div class="w3_agile_header">
						<div class="w3_agileits_logo">
								<h1><a href="home1">AGROMART<span><font color="yellow">BUY AND SALE THROUGH ONE WINDOW</font></span></a></h1>
								
							</div>
							<div class="w3_menu">
						<div class="agileits_w3layouts_banner_info">
			
								
						<!--	<a href="">	<span style="color:red;size:20px;" class="fa fa-user"></span>Login</a>
									<input type="search" name="search" placeholder=" " required="">
									<input type="submit" value="Search">-->
							
							</div>
								<div class="top-nav">
								<nav class="navbar navbar-default">
									<div class="container">
										<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">Menu						
										</button>
									</div>
									<!-- Collect the nav links, forms, and other content for toggling -->
									<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
										<ul class="nav navbar-nav">
											<li class="home-icon"><a href="/home1"><span class="fa fa-home" aria-hidden="true"></span></a></li>
											<li><a href="/about">About</a></li>
											<li><a href="/buy">Buy</a></li>
											
											<li><a href="/gallery">Gallery</a>
											<!--	<ul class="dropdown-menu">
													<li><a class="hvr-bounce-to-bottom" href="/gallery">Gallery</a></li>
													<li><a class="hvr-bounce-to-bottom" href="/contact">Contact Us</a></li>
												</ul>-->
											</li>
<li><a href="/regg">SignUp</a></li>											
											<li><a href="/loginn">SignIn</a></li>
											<li class="nav-cart-w3ls">
											<!--	<form action="#" method="post" class="last"> 
													<input type="hidden" name="cmd" value="_cart">
													<input type="hidden" name="display" value="1">
													<button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
												</form> 
											</li>-->
										</ul>	
										<div class="clearfix"> </div>
									</div>	
								</nav>	
							</div>
						</div>

					<div class="clearfix"></div>
			    </div>
				<!-- banner-text -->
				<div class="slider">
						<div class="callbacks_container">
							<ul class="rslides callbacks callbacks1" id="slider4">
								<li>
									<div class="agileits-banner-info">
											<h4><font color="pink">Variety of crops</font></h4>
												<h3>Just select your favourite crop</h3>
											</div>	
								</li>
								<li>
									<div class="agileits-banner-info">
											<h4><font color="pink">smile & shine</font></h4>
												<h3>Making your life more healthy!</h3>
											</div>	
								</li>
								<li>
									<div class="agileits-banner-info">
											   <h4><font color="pink">Need a healthy and peacefull life..?</font></h4>
											   <h3>charming & unexpected surprise</h3>
											</div>	
								</li>
							</ul>
						</div>
				</div>
			
			<!--banner Slider starts Here-->
			<div class="w3_agileits_social_media ">
			<h4><font size='10px'color="pink">Contact : +917034928659 email:reebaalex@gmail.com</font></h4>
				<!--<ul class="social-icons3">
				<li class="agileinfo_share">Contact</li>
					<li><a href="#" class="wthree_facebook"> <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#" class="wthree_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#" class="wthree_dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#" class="wthree_behance"><i class="fa fa-behance" aria-hidden="true"></i></a></li>
				</ul>-->
			</div>
      </div>
   </div>
     </div>
	 
<!-- //banner -->


<!-- About -->

						<!-- //Modal1 -->

<!--//footer-->

	<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
<!-- for-Clients -->
		<script src="js/owl.carousel.js"></script>
			<!-- requried-jsfiles-for owl -->
							        <script>
									    $(document).ready(function() {
									      $("#owl-demo2").owlCarousel({
									        items : 1,
									        lazyLoad : false,
									        autoPlay : true,
									        navigation : false,
									        navigationText :  false,
									        pagination : true,
									      });
									    });
									  </script>
									  
									  
									  
									  
									  
			<!-- //requried-jsfiles-for owl -->
	<!-- //for-Clients -->
<!-- cart-js -->
	<script src="js/minicart.min.js"></script>
	<script>
		// Mini Cart
		paypal.minicart.render({
			action: '#'
		});

		if (~window.location.search.indexOf('reset=true')) {
			paypal.minicart.reset();
		}
	</script>
<!-- //cart-js --> 
<!-- video-bg -->
<script src="js/jquery.vide.min.js"></script>
<!-- //video-bg -->
<!-- Nice scroll -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- //Nice scroll -->
<!-- for bootstrap working -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
<!-- //for bootstrap working -->
</body>
</html>