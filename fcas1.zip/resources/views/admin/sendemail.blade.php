
</<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AgroMart</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>
</head>
<body>
            <h3 style="color:#00c85f;background:rgba(0,0,0,0.1)">Message From AgroMart</h3>

            {{$e_message}}
</body>
</html>