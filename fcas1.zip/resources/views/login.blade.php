<!DOCTYPE html>
<html lang="zxx">
<head>
<title>AgroMart</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="prezzie Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=Tangerine:400,700" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
  
  
</head>
<body>
<!-- banner -->
<div class="banner_top" id="home">
	<div data-vide-bg ="video/gift">
		<div class="center-container inner-container">
			<div class="w3_agile_header">
						<div class="w3_agileits_logo">
								<h1><a href="/home1">AGROMART<span><font color="yellow">BUY AND SALE THROUGH ONE WINDOW</font></span></a></h1>
							</div>
							<div class="w3_menu">
							<div class="agileits_w3layouts_banner_info">
				
							<!--	<form action="#" method="post"> 
									<input type="search" name="search" placeholder=" " required="">
									<input type="submit" value="Search">
								</form>-->
							</div>
								<div class="top-nav">
								<nav class="navbar navbar-default">
									<div class="container">
										<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">Menu						
										</button>
									</div>
									<!-- Collect the nav links, forms, and other content for toggling -->
									<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
										<ul class="nav navbar-nav">
											<li class="home-icon"><a href="/home1"><span class="fa fa-home" aria-hidden="true"></span></a></li>
											<li><a href="/about">About</a></li>
											<li><a href="/buy">Buy</a></li>
											
											<li><a href="/gallery" class="dropdown-toggle hvr-bounce-to-bottom" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Gallery <span class="caret"></span></a>
											<!--	<ul class="dropdown-menu">
													<li><a class="hvr-bounce-to-bottom" href="/gallery">Gallery</a></li>
													<li><a class="hvr-bounce-to-bottom" href="/contact">Contact Us</a></li>
												</ul>-->
											</li>
<li><a href="/regg">SignUp</a></li>											
											<li><a href="/loginn">SignIn</a></li>
											<li class="nav-cart-w3ls">
											<!--	<form action="#" method="post" class="last"> 
													<input type="hidden" name="cmd" value="_cart">
													<input type="hidden" name="display" value="1">
													<button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
												</form> 
											</li>-->
										</ul>	
										<div class="clearfix"> </div>
									</div>	
								</nav>	
							</div>
						</div>

					<div class="clearfix"></div>
			    </div>
				<!-- banner-text -->
			<h2 class="inner-heading-agileits-w3layouts">Login Here</h2>
			<!--banner Slider starts Here-->
      </div>
   </div>
  
     </div>
 <center>
	<div class="agile-field-txt" style="background-image:(images/a.jpg);">
	  <br><br>
   <form action="/loginme" method="post">
			<div class="agile-field-txt">
				
				
				<h1>Login Here</h1>
				<label>
				<input type="hidden" name="_token" value="{{csrf_token()}}">
					<i class="fa fa-user" aria-hidden="true"></i> <font style="color:red;background-color:#fff;">Username :</font></label>
				<input type="text" name="username" placeholder="User Name please " required="" style="width: 20%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
			</div><br><br>
			<div class="agile-field-txt">
				<label>
					<i class="fa fa-envelope" aria-hidden="true"></i> <font style="color:red;background-color:#fff;">password :</font></label>
				<input type="password" name="password" placeholder=" Password Please " required="" id="myInput" style="width: 20%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"><br><br>
				<div class="agile_label">
					<input id="check3" name="check3" type="checkbox" value="show password" onclick="myFunction()">
					<label class="check" for="check3"><font style="color:red;background-color:#fff;">Show password</font></label><br><br>
					
				</div>
				<a href=""><font style="color:pink;font-weight:italic;font-size:15px;">Forget password</font></a>
					<a href="/regg" ><font style="color:pink;font-weight:italic;font-size:15px;">||  Create An Account</font></a>
			</div>
			<div class="w3ls-bot">
			<div class="form-end">
					<input type="submit" value="LOGIN" style="width: 10%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
				</div>
				<div class="clearfix"></div><br><br>
				
			</div>
			<!-- script for show password -->
			<script>
				function myFunction() {
					var x = document.getElementById("myInput");
					if (x.type === "password") {
						x.type = "text";
					} else {
						x.type = "password";
					}
				}
			</script>
			<!-- //script ends here -->
			<!--<div class="w3ls-bot">
			<div class="switch-agileits">
				<label class="switch">
						<input type="checkbox">
						<span class="slider round"></span>
					<font style="color:pink;">	keep me signed in</font>
					</label>
					
				</div>
				
			
				<div class="form-end">
					<input type="submit" value="LOGIN">
				</div>
				<div class="clearfix"></div><br><br>
				
			</div>-->
		</form>
		</div>
		
   </center>
	 </body>
	 </html>