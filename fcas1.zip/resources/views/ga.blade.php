@foreach($data as $user)

<img src="{{asset('storage/upload/'.$user->aadharcard)}}">
@endforeach