<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>AgroMart</title>
<!-- 
Moonlight Template 
http://www.templatemo.com/tm-512-moonlight
-->
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="prezzie Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=Tangerine:400,700" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/fontAwesome.css">
        <link rel="stylesheet" href="css/light-box.css">
        <link rel="stylesheet" href="css/templatemo-main.css">
		        
       <link rel="stylesheet" href="css/templatemo-main1.css">

     <!--   <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">-->

        <script src="jsl/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
		<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 50%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>
    </head>
	<body>
	<div class="banner_top" id="home">
	<div data-vide-bg ="video/gift">
		<div class="center-container inner-container">
			<div class="w3_agile_header">
						<div class="w3_agileits_logo">
								<h1><a href="/home1">AGROMART<span><font color="yellow">BUY AND SALE THROUGH ONE WINDOW</font></span></a></h1>
							</div>
							<div class="w3_menu">
							<div class="agileits_w3layouts_banner_info">
				
							<!--	<form action="#" method="post"> 
									<input type="search" name="search" placeholder=" " required="">
									<input type="submit" value="Search">
								</form>-->
							</div>
								<div class="top-nav">
								<nav class="navbar navbar-default">
									<div class="container">
										<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">Menu						
										</button>
									</div>
									<!-- Collect the nav links, forms, and other content for toggling -->
									<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
										<ul class="nav navbar-nav">
											<li class="home-icon"><a href="/home1"><span class="fa fa-home" aria-hidden="true"></span></a></li>
											<li><a href="/about">About</a></li>
											<li><a href="/buy">Buy</a></li>
											
											<li><a href="/gallery" class="dropdown-toggle hvr-bounce-to-bottom" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Gallery <span class="caret"></span></a>
											<!--	<ul class="dropdown-menu">
													<li><a class="hvr-bounce-to-bottom" href="/gallery">Gallery</a></li>
													<li><a class="hvr-bounce-to-bottom" href="/contact">Contact Us</a></li>
												</ul>-->
											</li>
<li><a href="/regg">SignUp</a></li>											
											<li><a href="/loginn">SignIn</a></li>
											<li class="nav-cart-w3ls">
											<!--	<form action="#" method="post" class="last"> 
													<input type="hidden" name="cmd" value="_cart">
													<input type="hidden" name="display" value="1">
													<button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
												</form> 
											</li>-->
										</ul>	
										<div class="clearfix"> </div>
									</div>	
								</nav>	
							</div>
						</div>

					<div class="clearfix"></div>
			    </div>
				<!-- banner-text -->
			<h2 class="inner-heading-agileits-w3layouts">Welcome</h2>
			<!--banner Slider starts Here-->
      </div>
   </div>
  
     </div>
	<div class="w3ls-login box box--big" style="background-color:red;">

		<!-- form starts here -->
		<form action="/loginme" method="post">
			<div class="agile-field-txt">
				<a href=""><font style="color:pink;font-weight:italic;font-size:15px;">Forget password</font></a>
					<a href="/regg" ><font style="color:pink;font-weight:italic;font-size:15px;">||  Create An Account</font></a>
				<br><br>
				
				<label>
				<input type="hidden" name="_token" value="{{csrf_token()}}">
					<i class="fa fa-user" aria-hidden="true"></i> <font style="color:red;background-color:#fff;">Username :</font></label>
				<input type="text" name="username" placeholder="User Name please " required="" />
			</div>
			<div class="agile-field-txt">
				<label>
					<i class="fa fa-envelope" aria-hidden="true"></i> <font style="color:red;background-color:#fff;">password :</font></label>
				<input type="password" name="password" placeholder=" Password Please " required="" id="myInput" />
				<div class="agile_label">
					<input id="check3" name="check3" type="checkbox" value="show password" onclick="myFunction()">
					<label class="check" for="check3"><font style="color:red;background-color:#fff;">Show password</font></label><br><br>
					
				</div>
			</div>
			<div class="w3ls-bot">
			<div class="form-end">
					<input type="submit" value="LOGIN" style="width:150px;">
				</div>
				<div class="clearfix"></div><br><br>
				
			</div>
			<!-- script for show password -->
			<script>
				function myFunction() {
					var x = document.getElementById("myInput");
					if (x.type === "password") {
						x.type = "text";
					} else {
						x.type = "password";
					}
				}
			</script>
			<!-- //script ends here -->
			<!--<div class="w3ls-bot">
			<div class="switch-agileits">
				<label class="switch">
						<input type="checkbox">
						<span class="slider round"></span>
					<font style="color:pink;">	keep me signed in</font>
					</label>
					
				</div>
				
			
				<div class="form-end">
					<input type="submit" value="LOGIN">
				</div>
				<div class="clearfix"></div><br><br>
				
			</div>-->
		</form>
		
		</div>
		<center>
		<div id="myModal" class="modal" style="width:100px;height:100px;">

  <!-- Modal content -->
  <div class="modal-content" >
    <span class="close">&times;</span>
    <form action="/data" method="post">
	<input type="hidden" name="_token" value="{{csrf_token()}}">
	<input type="text" value="haii">
	</div>

</div>
	</center>
		
		
		
		
		
		</div>
		
		<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("ser1");


// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];


// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

</script>

     <!--   <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>-->
    <script>window.jQuery || document.write('<script src="jsl/vendor/jquery-1.11.2.min.js"><\/script>')</script>

    <script src="jsl/vendor/bootstrap.min.js"></script>
    
    <script src="jsl/datepicker.js"></script>
    <script src="jsl/plugins.js"></script>
    <script src="jsl/main.js"></script>

<!--    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>-->
    <script type="text/javascript">
    $(document).ready(function() {

        

        // navigation click actions 
        $('.scroll-link').on('click', function(event){
            event.preventDefault();
            var sectionID = $(this).attr("data-id");
            scrollToID('#' + sectionID, 750);
        });
        // scroll to top action
        $('.scroll-top').on('click', function(event) {
            event.preventDefault();
            $('html, body').animate({scrollTop:0}, 'slow');         
        });
        // mobile nav toggle
        $('#nav-toggle').on('click', function (event) {
            event.preventDefault();
            $('#main-nav').toggleClass("open");
        });
    });
    // scroll function
    function scrollToID(id, speed){
        var offSet = 0;
        var targetOffset = $(id).offset().top - offSet;
        var mainNav = $('#main-nav');
        $('html,body').animate({scrollTop:targetOffset}, speed);
        if (mainNav.hasClass("open")) {
            mainNav.css("height", "1px").removeClass("in").addClass("collapse");
            mainNav.removeClass("open");
        }
    }
    if (typeof console === "undefined") {
        console = {
            log: function() { }
        };
    }
    </script>

</body>
</html>