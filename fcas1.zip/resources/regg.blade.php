<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>AgroMart</title>
<!-- 
Moonlight Template 
http://www.templatemo.com/tm-512-moonlight
-->
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

      <!--<link rel="stylesheet" href="css/bootstrap.min.css">
       <link rel="stylesheet" href="css/bootstrap-theme.min.css">-->
        <link rel="stylesheet" href="css/fontAwesome.css">
        <link rel="stylesheet" href="css/light-box.css">
       <link rel="stylesheet" href="css/templatemo-main1.css">
<meta charset="utf-8">
  
  
     <!--   <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">-->

        <script src="jsl/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
		<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 50%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>
    </head>
	<body style="background-image:url(images/9.jpeg);">
    
   <!-- <div class="sequence">
  
      <div class="seq-preloader">
        <svg width="39" height="16" viewBox="0 0 39 16" xmlns="http://www.w3.org/2000/svg" class="seq-preload-indicator"><g fill="#F96D38"><path class="seq-preload-circle seq-preload-circle-1" d="M3.999 12.012c2.209 0 3.999-1.791 3.999-3.999s-1.79-3.999-3.999-3.999-3.999 1.791-3.999 3.999 1.79 3.999 3.999 3.999z"/><path class="seq-preload-circle seq-preload-circle-2" d="M15.996 13.468c3.018 0 5.465-2.447 5.465-5.466 0-3.018-2.447-5.465-5.465-5.465-3.019 0-5.466 2.447-5.466 5.465 0 3.019 2.447 5.466 5.466 5.466z"/><path class="seq-preload-circle seq-preload-circle-3" d="M31.322 15.334c4.049 0 7.332-3.282 7.332-7.332 0-4.049-3.282-7.332-7.332-7.332s-7.332 3.283-7.332 7.332c0 4.05 3.283 7.332 7.332 7.332z"/></g></svg>
      </div>
      
    </div>--> {{ csrf_field() }}
	<nav><center><font color="pink" size="20px">AgroMart</font></center>
         <!-- <div class="logo">
              <img src="images/d.jpg" alt="">
          </div>-->
          <div class="mini-logo">
              <img src="images/a.jpeg" alt="">
          </div>
          <ul>
            <li><a href="/home1"><i class="fa fa-home"></i> <em>Home</em></a></li>
            <li><a href="/about"><i class="fa fa-user"></i> <em>About</em></a></li>
            <li><a href="/buy"><i class="fa fa-pencil"></i> <em>Buy</em></a></li>
			<li><a href="/service"><i class="fa fa-pencil"></i> <em>Services</em></a></li>
			
            <li><a href="/loginn"><i class="fa fa-image"></i> <em>SignIn</em></a></li>
            <li><a href="/regg"><i class="fa fa-envelope"></i> <em>SignUp</em></a></li>
          </ul>
        </nav>
		<div class="one"><center><br><br><br>
		<h1><font color="#00BCD4">Register Here...</font></h1><br><br><br>
	<div class="w3ls-login box box--big">

   <h2>Modal Example</h2>

<!-- Trigger/Open The Modal -->
<!--<button id="myBtn">Open Modal</button>-->
<input type="radio" id="myBtn">Farmer
<input type="radio" id="myBtn1">Customer
<!-- for farmer form-->
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <form action="/data" method="post">
	<input type="hidden" name="_token" value="{{csrf_token()}}">
            <table><tr><td>First Name:</td><td><input type="text" name="fname" autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td><td></td>
		<td>Last Name:</td><td><input type="text" name="lname"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>
        <tr><td>Email Id:</td><td><input type="email" name="email"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td><td></td>
<td>Mobile No:</td><td><input type="text" name="phone"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><br><br><br>
	
<tr><td>House Name:</td><td><input type="text" name="hname"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td><td></td>

        <td>House No:</td><td><input type="text" name="hno"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>
		<tr><td>Country:</td><td><select name="country"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
	<option value="">select</option>
                        <option value="india">India</option>
                        
                    </select></td><td></td>
		<td>State:</td><td><select name="state"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
	<option value="">select</option>
                        <option value="kerala">Kerala</option>
                        
                    </select></td></tr>
		<tr><td>District:</td><td><select name="district"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
	<option value="">select</option>
                        <option value="kasorgode">Kasorgode</option>
                        <option value="kannur">Kannur</option>
                        <option value="malapuram">Malapuram</option>
                        <option value="kozikodu">Kozikodu</option>
                        <option value="vyanadu">Vyanadu</option>
                        <option value="thrissur">Thrissur</option>
                        <option value="edukki">Idukki</option>
                        <option value="kottayam">Kottayam</option>
						<option value="eranakulam">Eranakulam</option>
                        <option value="alapuzha">Alapuzha</option>
                        <option value="patahnamthitta">Pathanamthitta</option>
                        <option value="kollam">Kollam</option>
                        <option value="plakadu">Plakadu</option>
                        <option value="tvm">Thruvanathapuram</option>
                    </select></td><td></td>
					<td>Panchayath:</td><td><input type="text" name="pan"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>	
<tr><td>PIN:</td><td><input type="text" name="pin"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td><td></td>
<td>Password:</td><td><input type="password" name="password"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>	
<tr><td>Confirm Password:</td><td><input type="password" name="cpassword"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td>
	<td></td><td></td><td><input type="submit" name="submit" value="submit" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr></table>
        </form>
  </div>
</div>  

<!-- The Modal -->
<div id="myModal1" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close1">&times;</span>
    <form action="/data1" method="post">
	<input type="hidden" name="_token" value="{{csrf_token()}}">
            <table><tr><td>First Name:</td><td><input type="text" name="fname" autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td>
		<td>Last Name:</td><td><input type="text" name="lname"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>
        <tr><td>Email Id:</td><td><input type="email" name="email"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td>
<td>Phone No:</td><td><input type="text" name="phone"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><br><br><br>
	
<tr><td>House Name:</td><td><input type="text" name="hname"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td>

        <td>House No:</td><td><input type="text" name="hno"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>
		<tr><td>Country:</td><td><select name="country"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
	<option value="">select</option>
                        <option value="india">India</option>
                        
                    </select></td>
		<td>State:</td><td><select name="state"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
	<option value="">select</option>
                        <option value="kerala">Kerala</option>
                        
                    </select></td></tr>
		<tr><td>District:</td><td><select name="district"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;">
	<option value="">select</option>
                        <option value="kasorgode">Kasorgode</option>
                        <option value="kannur">Kannur</option>
                        <option value="malapuram">Malapuram</option>
                        <option value="kozikodu">Kozikodu</option>
                        <option value="vyanadu">Vyanadu</option>
                        <option value="thrissur">Thrissur</option>
                        <option value="edukki">Idukki</option>
                        <option value="kottayam">Kottayam</option>
						<option value="eranakulam">Eranakulam</option>
                        <option value="alapuzha">Alapuzha</option>
                        <option value="patahnamthitta">Pathanamthitta</option>
                        <option value="kollam">Kollam</option>
                        <option value="plakadu">Plakadu</option>
                        <option value="tvm">Thruvanathapuram</option>
                    </select></td>
					<td>Panchayath:</td><td><input type="text" name="pan"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>	
<tr><td>PIN:</td><td><input type="text" name="pin"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td>
<td>Password:</td><td><input type="password" name="password"autocomplete="off"style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr>	
<tr><td>Confirm Password:</td><td><input type="password" name="cpassword"autocomplete="off" style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td><td></td><td><input type="submit" name="submit" value="Submit"   style="width: 100%;
    color: #00bcd4;
    outline: none;
    font-size: 16px;
    letter-spacing: 0.5px;padding: 15px;
    box-sizing: border-box;
    border: none;
	border-radius: 8px;
    border: 5px double #00bcd4;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.49);
    -webkit-appearance: none;
    font-family: 'Source Sans Pro', sans-serif;"></td></tr></table>
        </form>
  </div>

</div>


  
</div>
		
	</div>	
		
		
		
		
		



 
		
		
		

    <script>
// Get the modal
var modal = document.getElementById('myModal');
var modal1 = document.getElementById('myModal1');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");
var btn1 = document.getElementById("myBtn1");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
var span1 = document.getElementsByClassName("close1")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}
btn1.onclick = function() {
  modal1.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}
span1.onclick = function() {
  modal1.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
window.onclick = function(event) {
  if (event.target == modal1) {
    modal1.style.display = "none";
  }
}
</script>

		
		
		<script>window.jQuery || document.write('<script src="jsl/vendor/jquery-1.11.2.min.js"><\/script>')</script>

    <script src="jsl/vendor/bootstrap.min.js"></script>
    
    <script src="jsl/datepicker.js"></script>
    <script src="jsl/plugins.js"></script>
    <script src="jsl/main.js"></script>

<!--    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>-->
    <script type="text/javascript">
	
	$(document).ready(function() {
    $('input[type=radio]').live('change', function() { alert('wtf'); });
});

	
	
	
    $(document).ready(function() {

        

        // navigation click actions 
        $('.scroll-link').on('click', function(event){
            event.preventDefault();
            var sectionID = $(this).attr("data-id");
            scrollToID('#' + sectionID, 750);
        });
        // scroll to top action
        $('.scroll-top').on('click', function(event) {
            event.preventDefault();
            $('html, body').animate({scrollTop:0}, 'slow');         
        });
        // mobile nav toggle
        $('#nav-toggle').on('click', function (event) {
            event.preventDefault();
            $('#main-nav').toggleClass("open");
        });
    });
    // scroll function
    function scrollToID(id, speed){
        var offSet = 0;
        var targetOffset = $(id).offset().top - offSet;
        var mainNav = $('#main-nav');
        $('html,body').animate({scrollTop:targetOffset}, speed);
        if (mainNav.hasClass("open")) {
            mainNav.css("height", "1px").removeClass("in").addClass("collapse");
            mainNav.removeClass("open");
        }
    }
    if (typeof console === "undefined") {
        console = {
            log: function() { }
        };
    }
    </script>
</body>
</html>




<!DOCTYPE html>
<html lang="en">
<head>

     <title>AgroMart</title>
<!-- 
Hydro Template 
http://www.templatemo.com/tm-509-hydro
-->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css3/bootstrap.min.css">
     <link rel="stylesheet" href="css3/magnific-popup.css">
     <link rel="stylesheet" href="css3/font-awesome.min.css">

     <link rel="stylesheet" href="css3/templatemo-style.css">
	 <!-- Adding oh-autoVal css style -->
<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
<!-- Adding jQuery script. It must be before other script files -->
<script src="js/jquery.min.js"> </script>
<!-- Adding oh-autoVal script file -->
<script src="js/oh-autoval-script.js"></script>
</head>
<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="/" class="navbar-brand">AGROMART</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="/" class="smoothScroll"><font size="5px">Home</font></a></li>
                         <li><a href="/about" class="smoothScroll"><font size="5px">About</font></a></li>
                         <li><a href="/buy" class="smoothScroll"><font size="5px">Buy</font></a></li>
                         <li><a href="/gallery" class="smoothScroll"><font size="5px">Gallery</font></a></li>
                         
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
                         <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                         <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                         <li class="section-btn"><a href="#" data-toggle="modal" data-target="#modal-form">Sign in </a></li>
						  <li class="section-btn"><a href="/regg">Join</a></li>
                    </ul>
               </div>

          </div>
     </section>


     <!-- HOME -->
     <section id="home" data-stellar-background-ratio="0.5">
          <div class="overlay"></div>
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="home-info">
                              <h1>BUY AND SALE THROUGH ONE WINDOW</h1><center>
                           <!-- <span>
                            <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                   <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
               </span></div>--><center>

                                              <h2>AgroMart</h2>
                                   

                                       <table>
                                                  <form action="/data"  method="post" name="register" class="oh-autoval-form" onsubmit="return" enctype="multipart/form-data">
										<tr><td>		  <input type="hidden" name="_token" value="{{csrf_token()}}"></td></tr>
                                               <tr><td><input type="text" class="form-control"  name="fname" id="firstname" placeholder="First Name" autocomplete="off" required onchange='Validlast1();'>
													   </td>
													     <script>		
function Validlast1() 
{
    var val = document.getElementById('firstname').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet ');
		            document.getElementById('firstname').focus();
        return false;
    }

    return true;
}

</script>              
													   
													   
													<td>   <input type="text" class="form-control "  name="lname" id="l" placeholder="Last Name"autocomplete="off"required onchange='Validlast();' >
                              </td></tr>
                              
                              <script>		
function Validlast() 
{
    var val = document.getElementById('l').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet');
        document.getElementById('l').focus();
        return false;
    }

    return true;
}

</script>                         
											<tr><td>           <input type="email" class="form-control"  id="e"  name="email" placeholder="Email"autocomplete="off" required onchange='Validem();'>
													   
		
          </td>
          
          <script>		
function Validem() 
{
    var val = document.getElementById('e').value;

    if (!val.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/)) 
    {
        alert('Incorrect Email ');
		
		    document.getElementById('e').focus();
        return false;
    }

    return true;
}

</script>													   
													   
										<td>			   <input type="telephone" class="form-control" name="phone" id="c" placeholder="Mobile Phone" autocomplete="off"required onchange='Validat();' >
</td></tr>

<script>		
function Validat() 
{
    var val = document.getElementById('c').value;

    if (!val.match(/^[6-9][0-9]{1,9}$/)) 
    {
        alert('Only Numbers are allowed start with 6,7,8,9 and contain 10 digits');
	
		
        document.getElementById('c').focus();
        return false;
    }

    return true;
}

</script>
													   
												<tr><td>	   <input type="file" class="form-control" name="pic" id="fileChooser" placeholder="profile pic" onchange='ValidateFileUpload();' required  >
                                                                   
                                                                   </td>
                                                                   
                                                                    <SCRIPT type="text/javascript">
    function ValidateFileUpload() {
        var fuData = document.getElementById('fileChooser');
        var FileUploadPath = fuData.value;

//To check if user upload any file
        if (FileUploadPath == '') {
            alert("Please upload an image");

        } else {
            var Extension = FileUploadPath.substring(
                    FileUploadPath.lastIndexOf('.') + 1).toLowerCase();

//The file uploaded is an image

if (Extension == "gif" || Extension == "png" || Extension == "bmp"
                    || Extension == "jpeg" || Extension == "jpg") {

// To Display
                if (fuData.files && fuData.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#blah').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(fuData.files[0]);
                }

            } 

//The file upload is NOT an image
else {
                alert("Photo only allows file types of GIF, PNG, JPG, JPEG and BMP. ");
                document.getElementById('fileChooser').focus();
            }
        }
    }
</SCRIPT>
													<td>   <input type="text" class="form-control  " name="hname" id="hname" placeholder="House Name" autocomplete="off" required onChange='validate();'>
                                                       </td></tr>
										
												

												
												<script>		
function validate() 
{
    var val = document.getElementById('hname').value;

    if (!val.match(/^[0-9a-zA-Z ]+$/)) 
    {
        alert('Only alphabets and numbers are allowed');
        document.getElementById('hname').focus();
        return false;
    }

    return true;
}

</script>
												
												
												
												
												
																	
													   
													   
													   
													   
													   
											<tr><td>		   <select name="country" id="country" autocomplete="off" placeholder="country" class="form-control av-required" av-message="required">
                                                       <option value="">Select Country</option>
                        
							 <option value="India">India</option>
						
                    </select></td>
											<td>		      <select name="state" id="state" autocomplete="off" placeholder="state" class="form-control av-required" av-message="required">
                                                       <option value="">Select State</option>
                        
							 <option value="kerala">Kerala</option>
						
                    </select></td></tr>
											<tr><td>		   <select name="district" id="district" autocomplete="off"placeholder="district" class="form-control av-required" av-message="required">
                                                       <option value="">select</option>
													   <option value="Kasorgode">Kasorgode</option>
													   <option value="Kannur">Kannur</option>
													   <option value="Kozikod">Kozikod</option>
													   <option value="malapuram">Malapuram</option>
													   <option value="wyanad">Wyanad</option>
													   <option value="thrissur">Thrissur</option>
													   <option value="palakad">Palakad</option>
													   <option value="alapuzha">Alapuzha</option>
													   <option value="Kottayam">Kottayam</option>
													   <option value="Kollam">Kollam</option>
													   <option value="Eranakulam">Eranakulam</option>
													   <option value="patahnamthitta">Patahnamthitta</option>
													   <option value="thiruvanathapuram">Thiruvanathapuram</option>
													   <option value="palakad">Palakad</option>
                      <!--  @foreach($states as $key => $state)
							 <option value="{{$key}}">{{$state}}</option>
							  @endforeach-->
                    </select></td>
													<td>   <input type="text" class="form-control av-name" av-message="must be letter also required" name="pan" id="pan"placeholder="Panchayath Name"autocomplete="off"class="form-control av-required av-name" av-message="Invalid panchayath name">
													   </td></tr>
                                                                    
                                                                    <!--<select name="pan" id="pan" autocomplete="off" required class="form-control">
													   <option value="">select</option>
                        
                    </select>-->
					 
					
                                                  <tr><td>     <input type="text" autocomplete="off" class="form-control av-pincode" av-message="6 gigit nuber& required"name="pin" placeholder="Pin Number" >
											</td>		   
                                                       
                                                     <td>  <input type="password" class="form-control av-password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars." id="pass" name="password" placeholder="Password">
                                             
												</td></tr>	   

													   
													   
													<tr><td>   <input type="password" class="form-control av-password" name="cpassword" id="cpass"placeholder=" Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.Similar to password" onChange='check();'>
												</td>
                                                            <script>	      
											function check(){
			if(document.getElementById("cpass").value!=document.getElementById("pass").value)
			{
			alert('Doesnot match with password');
				
		            document.getElementById('cpass').value = "";
            }
                                                       }
	</script>		   
													   
													  <td> <input type="submit" class="form-control" name="submit" value="Submit">
													   </td></tr>
                                                                    
                                                                     <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   
													   
													   
													   </script>
                                                  </form>
												
                                            </table></center>

                                           <!--  <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="#" method="post">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="https://www.facebook.com/templatemo">Forgot your password?</a>
                                                  </form>-->
                                     
      
                                   
	 
     
	 
	 
	<!-- <section class="modal fade" id="modal-form1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>-->

                                        <!-- NAV TABS -->
                                      <!--  <ul class="nav nav-tabs" role="tablist">
                                           <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Create an account</a></li>-->
                                           <!--  <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>
                                        </ul>-->

                                        <!-- TAB PANES -->
                                      <!--  <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                                  <form action="/data"  method="post" name="register" class="oh-autoval-form" onsubmit="return" enctype="multipart/form-data">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="text" class="form-control"  name="fname" id="firstname" placeholder="First Name" autocomplete="off" required onchange='Validlast1();'>
													   
													     <script>		
function Validlast1() 
{
    var val = document.getElementById('firstname').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet ');
		            document.getElementById('firstname').focus();
        return false;
    }

    return true;
}

</script>              
													   
													   
													   <input type="text" class="form-control "  name="lname" id="l" placeholder="Last Name"autocomplete="off"required onchange='Validlast();' >
                              <script>		
function Validlast() 
{
    var val = document.getElementById('l').value;

    if (!val.match(/^[A-Za-z][A-Za-z" "]{0,}$/)) 
    {
        alert('Only alphabets are allowed and Start with a Alphabet');
        document.getElementById('l').focus();
        return false;
    }

    return true;
}

</script>                         
											           <input type="email" class="form-control"  id="e"  name="email" placeholder="Email"autocomplete="off" required onchange='Validem();'>
													   
		<script>		
function Validem() 
{
    var val = document.getElementById('e').value;

    if (!val.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/)) 
    {
        alert('Incorrect Email ');
		
		    document.getElementById('e').focus();
        return false;
    }

    return true;
}

</script>													   
													   
													   <input type="telephone" class="form-control" name="phone" id="c" placeholder="Mobile Phone" autocomplete="off"required onchange='Validat();' >
<script>		
function Validat() 
{
    var val = document.getElementById('c').value;

    if (!val.match(/^[6-9][0-9]{1,9}$/)) 
    {
        alert('Only Numbers are allowed start with 6,7,8,9 and contain 10 digits');
	
		
        document.getElementById('c').focus();
        return false;
    }

    return true;
}

</script>
													   
													   <input type="file" class="form-control" name="pic" id="fileChooser" placeholder="profile pic" onchange='ValidateFileUpload();' required  >
                                                                    <SCRIPT type="text/javascript">
    function ValidateFileUpload() {
        var fuData = document.getElementById('fileChooser');
        var FileUploadPath = fuData.value;

//To check if user upload any file
        if (FileUploadPath == '') {
            alert("Please upload an image");

        } else {
            var Extension = FileUploadPath.substring(
                    FileUploadPath.lastIndexOf('.') + 1).toLowerCase();

//The file uploaded is an image

if (Extension == "gif" || Extension == "png" || Extension == "bmp"
                    || Extension == "jpeg" || Extension == "jpg") {

// To Display
                if (fuData.files && fuData.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#blah').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(fuData.files[0]);
                }

            } 

//The file upload is NOT an image
else {
                alert("Photo only allows file types of GIF, PNG, JPG, JPEG and BMP. ");
                document.getElementById('fileChooser').focus();
            }
        }
    }
</SCRIPT>
													   <input type="text" class="form-control  " name="hname" id="hname" placeholder="House Name" autocomplete="off" required onChange='validate();'>
                                                       
										
												

												
												<script>		
function validate() 
{
    var val = document.getElementById('hname').value;

    if (!val.match(/^[0-9a-zA-Z ]+$/)) 
    {
        alert('Only alphabets and numbers are allowed');
        document.getElementById('hname').focus();
        return false;
    }

    return true;
}

</script>
												
												
												
												
												
																	
													   
													   
													   
													   
													   
													   <select name="country" id="country" autocomplete="off" placeholder="country" class="form-control av-required" av-message="required">
                                                       <option value="">Select Country</option>
                        
							 <option value="India">India</option>
						
                    </select>
													      <select name="state" id="state" autocomplete="off" placeholder="state" class="form-control av-required" av-message="required">
                                                       <option value="">Select State</option>
                        
							 <option value="kerala">Kerala</option>
						
                    </select>
													   <select name="district" id="district" autocomplete="off"placeholder="district" class="form-control av-required" av-message="required">
                                                       <option value="">select</option>
													   <option value="Kasorgode">Kasorgode</option>
													   <option value="Kannur">Kannur</option>
													   <option value="Kozikod">Kozikod</option>
													   <option value="malapuram">Malapuram</option>
													   <option value="wyanad">Wyanad</option>
													   <option value="thrissur">Thrissur</option>
													   <option value="palakad">Palakad</option>
													   <option value="alapuzha">Alapuzha</option>
													   <option value="Kottayam">Kottayam</option>
													   <option value="Kollam">Kollam</option>
													   <option value="Eranakulam">Eranakulam</option>
													   <option value="patahnamthitta">Patahnamthitta</option>
													   <option value="thiruvanathapuram">Thiruvanathapuram</option>
													   <option value="palakad">Palakad</option>-->
                      <!--  @foreach($states as $key => $state)
							 <option value="{{$key}}">{{$state}}</option>
							  @endforeach-->
                  <!--  </select>-->
													<!--   <input type="text" class="form-control av-name" av-message="must be letter also required" name="pan" id="pan"placeholder="Panchayath Name"autocomplete="off"class="form-control av-required av-name" av-message="Invalid panchayath name">-->
													   <!--<select name="pan" id="pan" autocomplete="off" required class="form-control">
													   <option value="">select</option>
                        
                    </select>-->
					 
					
                                                   <!--    <input type="text" autocomplete="off" class="form-control av-pincode" av-message="6 gigit nuber& required"name="pin" placeholder="Pin Number" >
													   
                                                       
                                                       <input type="password" class="form-control av-password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars." id="pass" name="password" placeholder="Password">
                                             
													   

													   
													   
													   <input type="password" class="form-control av-password" name="cpassword" id="cpass"placeholder=" Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.Similar to password" onChange='check();'>
												<script>	      
											function check(){
			if(document.getElementById("cpass").value!=document.getElementById("pass").value)
			{
			alert('Doesnot match with password');
				
		            document.getElementById('cpass').value = "";
            }
                                                       }
	</script>		   
													   
													   <input type="submit" class="form-control" name="submit" value="Submit">
													    <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   
													   
													   
													   </script>
                                                  </form>
												
                                             </div>-->

                                           <!--  <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="#" method="post">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="https://www.facebook.com/templatemo">Forgot your password?</a>
                                                  </form>
                                             </div>-->
                                     <!--   </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>         
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   <button id="myBtn"class="btn section-btn smoothScroll" data-toggle="modal" data-target="#modal-form1">Farmer</button>-->
							
                                  
                                   
                                   
                                   

                                                       
                                                      		   
													    		   
                                             
																
                                                
                                                       		

   
    
	 
     <!-- MODAL -->
     <section class="modal fade" id="modal-form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>

                                        <!-- NAV TABS -->
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Sign In</a></li>
                                          <!--    <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>-->
                                        </ul>

                                        <!-- TAB PANES -->
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                            <form action="/loginme" method="post">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" autocomplete="off" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="LOGIN">
                                                      <!-- <a href="">Forgot your password?</a>-->
													  @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                                                  </form>
                                            <!--    <form action="#" method="post">
                                                       <input type="text" class="form-control" name="name" placeholder="Name" required>
                                                       <input type="telephone" class="form-control" name="telephone" placeholder="Telephone" required>
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                  </form>
												<a href="/regg"><font size="5px">Farmer</font></a>
												  <a href="">Customer</a>-->
                                             </div>

                                           <!--  <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="/loginme" method="post">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" autocomplete="off" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                      <a href="">Forgot your password?</a>
													  @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                                                  </form>
                                             </div>-->
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>
	 
     
	 
	
	 
	 
	 
	<!--  <section class="modal fade" id="modal-form2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
               <div class="modal-content modal-popup">

                    <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                         </button>
                    </div>

                    <div class="modal-body">
                         <div class="container-fluid">
                              <div class="row">

                                   <div class="col-md-12 col-sm-12">
                                        <div class="modal-title">
                                             <h2>AgroMart</h2>
                                        </div>-->

                                        <!-- NAV TABS 
                                        <ul class="nav nav-tabs" role="tablist">
                                          <li class="active"><a href="#sign_up" aria-controls="sign_up" role="tab" data-toggle="tab">Create an account</a></li>-->
                                            <!-- <li><a href="#sign_in" aria-controls="sign_in" role="tab" data-toggle="tab">Sign In</a></li>
                                        </ul>-->

                                        <!-- TAB PANES 
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane fade in active" id="sign_up">
                                                  <form action="/data1" class="oh-autoval-form" method="post" onsubmit="return" id="register">
												  <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                       <input type="text"  name="firstname" id="firstname" placeholder="Name" autocomplete="off" class="form-control" pattern="[a-zA-Z\s]+" required >
                                                       
                                                      		   
													    		   
                                             
																
                                                
                                                       <input type="email" class="form-control "  name="email" id="e1" placeholder="Email" autocomplete="off" required onChange='Validem1();'>
													   
													   <script>		
function Validem1() 
{
    var val = document.getElementById('e1').value;

    if (!val.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) 
    {
        alert('Incorrect Email');
		
		     document.getElementById('e1').value = "";
        return false;
    }

    return true;
}

</script>
													   
													   <input type="password" class="form-control av-password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars.Similar to password" name="password" id="pass" placeholder="Password" autocomplete="off">
													   <input type="password" class="form-control av-password" name="cpassword" id="cpass"placeholder=" Confirm Password" av-message="Password must contain uppercase,lowercase,special chars,digits and minimum 6 chars. &&&& Similar to password" autocomplete="off" onChange='check();'>
                                                       
													   <script>
													   
	function check(){
			if(document.getElementById("cpass").value!=document.getElementById("pass").value)
			{
			alert('Doesnot match with password');
				
		            document.getElementById('cpass').value = "";
            }
		else{
			alert(' matched');
			}}
	</script>							   
													
													   <input type="submit" class="form-control" name="submit" value="Submit Button">
													   <script>
													  var msg='{{Session::get('alert')}}' ;
													   var exist='{{Session::has('alert')}}' ; 
													   if(exist)
													   {
													   alert(msg);}													   
													   
													   
													   
													   </script>
                                                  </form>
												<a href="/regg"><font size="5px">Farmer</font></a>
												  <a href="">Customer</a>
                                             </div>-->

                                            <!-- <div role="tabpanel" class="tab-pane fade in" id="sign_in">
                                                  <form action="#" method="post">
                                                       <input type="email" class="form-control" name="email" placeholder="Email" required>
                                                       <input type="password" class="form-control" name="password" placeholder="Password" required>
                                                       <input type="submit" class="form-control" name="submit" value="Submit Button">
                                                       <a href="https://www.facebook.com/templatemo">Forgot your password?</a>
                                                  </form>
                                             </div>
                                        </div>
                                   </div>

                              </div>
                         </div>
                    </div>

               </div>
          </div>
     </section>-->
	 


	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
     <script src="js3/jquery.js"></script>
     <script src="js3/bootstrap.min.js"></script>
     <script src="js3/jquery.stellar.min.js"></script>
     <script src="js3/jquery.magnific-popup.min.js"></script>
     <script src="js3/smoothscroll.js"></script>
     <script src="js3/custom.js"></script>
	
	 

</body>
</html>
